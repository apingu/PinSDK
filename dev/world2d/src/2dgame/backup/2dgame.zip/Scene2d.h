//surface.h header file of surface.cpp
//
// surface
//
//
//
//
//
//
//
//
//
//
//                                               Copyright    (C)    1999    Pin
//
#ifndef SCENE2D_H
#define SCENE2D_H

#include <VMC.h>
#include <VMCText.h>
#include <GSpace.h>
#include <Element2d.h>
//#include <DynArray.tl>
#include <DataStream.h>
#include <tPath.h>

namespace GE
{
    ////////////////////////////////////////////////////////////////////////////////////////////
    //  surface class
    class Scene2d : public DataStream, public GameSpace
    {

    protected:

        LGB::VMC*       m_pRender;  //image

    public:

        VMCText         m_Font;     //font

    public:

        Scene2d();
        ~Scene2d();

		void            PasteTerrain( LGB::CMemCanvas* canvas );

        void            SetRender( LGB::VMC* vmc );
        LGB::VMC*       GetRender( void );
        
        Element2d*      Element( Puint i )
        {
            return ( !IsEntityEmpty() && ( i < EntityCount() ) ) ?
                   ( ( Element2d * ) Entity( i ) ) : 0;
        }

		void            InsertEntity( Element2d* elem );
		void            RemoveEntity( Element2d* elem );
        void            SetFocusEntity( Element2d* elm );
        Element2d*      GetFocusEntity( void );


        //int             Scene_Width( void )  { return ( Image() == 0 ) ? 0 : Image()->width;  } //�a�Ϫ��e
        //int             Scene_Height( void ) { return ( Image() == 0 ) ? 0 : Image()->height; } //�a�Ϫ���

        //virtual int     LoadBackGround( const char* path );
        //virtual void    PasteBackGround( CPIcon* canvas );
        //virtual void    PasteEntity( int i, CPIcon* canvas );
		/*
        virtual void    Flip_Scene( CPIcon* canvas,
                                    const char* path,
                                    int offset = 0 );
								
        virtual void    Collide_Scroll( POINT point );
		*/
    };

};//namespace GE
#endif


