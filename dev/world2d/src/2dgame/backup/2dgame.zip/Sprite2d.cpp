// Body.cpp game element data store class
//
//
//
//
//
//
//
//
//
//
//
//
//                                               Copyright    (C)    1999    Pin
//

#include "Sprite2d.h"
#include <Debug.h>
#include <PFile.h>

namespace GE
{
    //#include <crtdbg.h>



    //////////////////////////////////////////////////////////////////////////////////////////////
    //  Sprite2d class


    //=============================================================================
    //  Name : 
    //  Desc : constructor
    //=============================================================================
    Sprite2d::Sprite2d()
    {
        Initiate();
    }


    //=============================================================================
    //  Name : 
    //  Desc : distructor
    //=============================================================================
    Sprite2d::~Sprite2d()
    {
        Release();
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Sprite2d::Initiate( void )
    {
        m_Init_Step = 0;
        m_Init_Clockcycle = 0;
		m_Focus = _LOST_FOCUS;
        m_MaxAspect = 1;              //��V��
        m_Collision = 0;              //�I������Flag
        m_ReferCount = 0;
        m_Step = 2;
        m_NowAct = 0;
        m_NowAspect = 0;              //�ثe�ʧ@����V
        m_NowDeedStatus = 0;
        m_NowFrameStatus = 0;

		m_Descriptor = NULL;
		m_pScreenDatum = NULL;

		m_tmp_distance = 0;           //�s��p�Ⲿ�ʶZ��
        m_tmp_focus_elm_relative_pos( 0, 0 ); //temp for drag

        ID = -1; 
        GID = -1;
        Moveable = true;
        Visible = true;
        Enable = true;
        Dragable = false;
        m_Position( 0, 0 );         //�a�Ϧ�m

        //m_WantToDo.clear();
        m_Route.clear();
        m_fname.clear();

        m_StepRate.SetCycle( 50 );
        m_FlipRate.SetCycle( 150 );
        //m_FlipRate.SetCycle( 150 );
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Sprite2d::Release( void )
    {
        if( m_fname.empty() )
            m_fname.release();
        m_Route.clear();

        if( m_ReferCount != NULL )
        {
            if( ( *m_ReferCount ) == 0 )
                SAFE_DELETE( m_ReferCount );
        }
    }




    /*
    //=============================================================================
    //  Name : Action_ID()
    //  Desc :
    //=============================================================================
    int Sprite2d::Action_ID( int act, int dir ) //�p��ʧ@��ID
    {
        return ( (act * m_MaxAspect) + dir );
    }
    */


    /*
    //=============================================================================
    //  Name : Set_Step()
    //  Desc :
    //=============================================================================
    void Sprite2d::Set_Step(int step)
    {
        m_Step = step;
        return;
    }
    */

    //=============================================================================


    //=============================================================================
    //  Name : Restore_Speed()
    //  Desc :
    //=============================================================================
    void Sprite2d::Restore_Speed( void )
    {
        m_Step = m_Init_Step;
        m_FlipRate.SetCycle( m_Init_Clockcycle );
        //m_FlipRate.SetCycle( m_Init_Clockcycle );
    }

};//namespace GE












