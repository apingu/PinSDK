//Element.cpp game world base class
//
//
//
//
//
//
//
//
//
//
//
//                                                              Pin
//                                                                  2000 11 08
//                                               Copyright    (C)    1999    Pin
//

#include <assert.h>
#include <fString.h>
#include <PFile.h>
#include "Element2d.h"
//#include "..\World\Map.h"


namespace GE
{
    char HEADLENAME[ 5 ]={"H.D"};
    char ACTIONNAME[ 5 ]={"A.T"};
    char IMAGENAME[ 5 ] ={"I.L"};

	static std::vector<GE::Element2d*> gElementList;

    //////////////////////////////////////////////////////////////////////////////////////////////
    //
    // �����զ�Element2d
    //
    //////////////////////////////////////////////////////////////////////////////////////////////
    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    Element2d::Element2d()
    {
		memcpy( &CID, "ELEM", sizeof( CID ) );
        //SpeedUp( 6 );
        m_parent = NULL;
        m_master = NULL;
		//m_World    = 0;
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    Element2d::~Element2d()
    {
        //Release();
		for( UINT i=0; i<gElementList.size(); i++ )
		{
			if( gElementList[i] == this )
			{
				gElementList.erase( gElementList.begin()+i );
				break;
			}
		}
    }


    //=============================================================================
    //  Name : Data_Read()
    //  Desc :
    //=============================================================================
    void Element2d::SetElemData( H2DPELEM data )
    {
        //ID                = data.ID;                         //CPElement id
        //GID               = data.GID;                        //CPElement group id
        //m_Job             = data.Job;
        Visible  = data.Visible;                     //�i��
        Dragable = data.Dragable;                    //�i�즲
        Enable   = data.Enable;                      //�i�@��
        Moveable = data.Moveable;                    //�i����
		m_AngleOfView = data.AngleOfView;
        m_MaxAspect   = data.MaxAspect;
        m_Init_Step   = data.MoveDistance;             //�����I��
        m_Init_Clockcycle = data.ClockCycle;
        //m_Position( data.InitSitusX, data.InitSitusY );     //�X�{�ɪ���m

        m_Step = data.MoveDistance;                //�����I��
        m_FlipRate.SetCycle( data.ClockCycle );
        //m_FlipRate.SetCycle( data.ClockCycle );             //�ʧ@���g���ɶ�
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Element2d::GetElemData( H2DPELEM* data )
    {
        //data->ID             = ID;        //CPElement id
        //data->GID            = GID;       //CPElement group id
        data->MoveDistance = m_Step;        //CPElement move distance
        //data->Job            = m_Job;
        //data->Identity       = m_Identity;
        data->Visible  = BOOLEAN( Visible );//static_cast<bool>( Visible );       //�i��
        data->Dragable = BOOLEAN( Dragable );//static_cast<bool>( Dragable );      //�i�즲
        data->Enable   = BOOLEAN( Enable );//static_cast<bool>( Enable );        //�i�@��
        data->Moveable = BOOLEAN( Moveable );//static_cast<bool>( Moveable );      //�i����

		data->AngleOfView = m_AngleOfView;
        data->MaxAspect   = m_MaxAspect;
        data->ClockCycle  = m_FlipRate.GetCycle();  //�ʧ@���g���ɶ�

        //data->InitSitusX     = m_Position.x;    //�X�{�ɪ���m
        //data->InitSitusY     = m_Position.y;    //�X�{�ɪ���m

        return;
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Element2d::Release( void )
    {
        ImageListRelease();
        Sprite2d::Release();
    }


    //=============================================================================
    //  Name :
    //  Desc :
    //=============================================================================
    Element2d* Element2d::breed( void )
    {
        Element2d* obj  = new Element2d;
        /*
        *obj = *this;
        obj->m_Parent = this;
        obj->ID = (((*(this->m_ReferCount)) - 1) * 1000 + this->ID);
        */
        return obj;
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    Element2d& Element2d::operator =( Element2d elm )
    {
        /*
        memcpy(this, &elm, sizeof(Element2d));
        (*m_ReferCount) ++;
        m_Parent = 0;
        int ActCount = elm.m_AnimTable.Sequence_count();
        m_AnimTable.m_Sequence->allot( ActCount );
        for(int aci = 0; aci < ActCount; aci++)
        {
            WORD ActStepCount = elm.m_AnimTable[aci]->size();
            (*m_AnimTable.m_Sequence)[ aci ] = new Sequence;
            for(int acsi = 0; acsi < ActStepCount; acsi++)
            {
                Pword StepNo = elm.m_AnimTable.Frame_ID( aci, acsi );
                m_AnimTable[aci]->push_back(StepNo);
            }
            m_AnimTable[aci]->GoBegin();
        }
        if( m_AnimTable.is_empty() )
            m_AnimTable.lp_Now_Frame = 0;
        else
            m_AnimTable.lp_Now_Frame = m_AnimTable[0]->begin();
        m_ImageList
        //m_TarGet.clear();
        */

        return *this;
    }



    //============================================================================================
    //   H.D   headle data
    //   A.T   action table
    //   I.L   image  list
    //   E.S   elm    string
    //============================================================================================
    int Element2d::Load( const char* elmpath )
    {
        /*  read headle data */
        char msg[ _MAX_MSG ];
        int result  = 0;

        CPFile pf;
        if( pf.open( elmpath ) == NULL )
        {
            sprintf( msg, "open element file %s failure -_-b", elmpath );
            DebugMessage( msg, "Element2d" );
            return pf.ferrno();
        }

        m_fname = elmpath;

        /* is a element file? */
        //pf.Lock_On(offSet);
        if( pf.checkFormat( "EM" ) != _PF_OK )
        {
            sprintf( msg, "%s not a element file -_-b", elmpath );
            DebugMessage( msg, "Element2d" );
            return pf.ferrno();
        }

        /* load H.D */
        //if( pf.Lock_On_F("H.D") == _ERR_FILE_NOT_FIND )
        //CPString hs( m_fname + "?H.D" );
        //CPString hs;
        char hs[ _MAX_FNAME ];
        sprintf( hs, "%s%s%s", filename(), "?", HEADLENAME );
        if( pf.bfind( ( Pstr ) hs ) == _ERR_FILE_NOT_FIND )
        {
            sprintf( msg, "%s read H.D file failure -_-b", elmpath );
            DebugMessage( "msg", "Element2d" );
            return pf.ferrno();
        }

        H2DPELEM elmdata;
        pf.read( &elmdata, sizeof( elmdata ), 1 );
        SetElemData( elmdata );
        //pf.Lock_Return();

        /*============== load A.T ==============*/
        //pf.Lock_On(base);
        //CPString as( m_fname + "?A.T" );
        //CPString as;
        char as[ _MAX_FNAME ];
        sprintf( as, "%s%s%s", filename(), "?", ACTIONNAME );
        result = m_AnimTable.Load( ( Pstr ) as ); 
        if( result < 0 )
            return result;


        /*============== load I.L ==============*/
		GE::Element2d* elem=NULL;
		//find exist resource
		for( UINT i=0; i<gElementList.size(); i++ )
		{
			if( strcmp( gElementList[i]->filename(), elmpath ) == 0 )
			{
				elem = gElementList[i];
				break;
			}
		}

		if( elem==NULL )
		{
            char is[ _MAX_FNAME ];
            sprintf( is, "%s%s%s", filename(), "?", IMAGENAME );
            result = Resource2d::Load( (Pstr)is );
            if( result < 0 )
                return result;
		}
		else
		{

		}


        /*============== load E.S ==============*/
        //pf.Lock_On(base);
        //CPString es( m_fname + "?E.S");
        //m_Squence_Name_Table.Load( es() );
        /*=========== refer count ==============*/
        if( m_ReferCount == 0 )
        {
            m_ReferCount = new DWORD;
            ( *m_ReferCount ) = 0;
        }
        ( *m_ReferCount )++;

        pf.close();
		gElementList.push_back( this );

        return 1;
    }



    //============================================================================================
    //  Name : Save()
    //  Desc : save as .pelm file
    //============================================================================================
    void Element2d::Save( Pcstr elmpath )
    {
        char drive[ _MAX_DRIVE ];
        char dir[ _MAX_DIR ];
        char fname[ _MAX_FNAME ];
        char ext[ _MAX_EXT ];
        _splitpath( elmpath, drive, dir, fname, ext );

        //wtire data
        char HDpath[ _MAX_PATH ];
        _makepath( HDpath, drive, dir, "H", "D" );

        CPFile pf;
        if( ( pf.open( HDpath, "wb" ) ) == NULL )//�}�ɦp�G-1�h���ѡA�Ǧ^-1
        {
            char message[ _MAX_MSG ];
            sprintf( message, "save file %s failure !!!", HDpath );
            DebugMessage( message, "Element2d" );
            return;
        }

        H2DPELEM elmdata;
        GetElemData( &elmdata );
        pf.write( &elmdata, 1, sizeof( elmdata ) );
        pf.close();

        //==========write action table==========
        char ATpath[ _MAX_PATH ];
        _makepath( ATpath, drive, dir, "A", "T" );
        m_AnimTable.Save( ATpath );


        //==========write image==========
        char ILpath[ _MAX_PATH ];
        _makepath( ILpath, drive, dir, "I", "L" );
        Resource2d::Save( ILpath );


        //==========to combine file==========
        CPFile elm_combine  ( elmpath, "wb" );
        std::vector<const char*> paths;
        paths.push_back( HDpath );
        paths.push_back( ATpath );
        paths.push_back( ILpath );
        elm_combine.Packfiles( paths, "EM", _DELETE_SORUCE_FILE );
        elm_combine.close();

        return;
    }


    //============================================================================================
    //read data functon for 3tj
    //
    //============================================================================================
    void Element2d::Read( const char* filepath, int size, int NO, int Type )
    {
        //m_DataType = Type;
        //m_DataID   = NO  ;

        FILE* f;

        if( ( f = fopen( filepath, "rd" ) ) == NULL )
        {
            DebugMessage( "Load role data failure !!!", "Element2d" );
            return;
        }

        fseek( f, size * NO, SEEK_SET );
        fread( this, size, 1, f );

        fclose( f );
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    int Element2d::CompareOrder( Element2d& Element2d )
    {
        if( Pos().y > Element2d.Pos().y )
            return ID;
        else
            return Element2d.ID;
    }



    //=============================================================================
    //
    // is response end
    //=============================================================================
    /*
    Pbool Element2d::ResponseOver()
    {
        int count = 0;
        if(m_Now_Status != 0)
            count++;
        for(int i = 0 ; i < m_TarGet.size() ; i++)
            if(m_TarGet[i]->Get_Now_Status() != 0)
                count++;
        return (count != 0) ?FALSE :TRUE;
    }
    */
    /*
    //=============================================================================
    //
    // return object status   1:60  2:40  3:20  4:0
    //=============================================================================
    void Element2d::SpeedUp(int speed)
    {
        m_Step = speed;
        switch(m_Step)
        {
        case 1: m_Rate.Setcycle(700); break;
        case 2: m_Rate.Setcycle(550); break;
        case 3: m_Rate.Setcycle(100); break;
        case 4: m_Rate.Setcycle(30);  break;
        case 5: m_Rate.Setcycle(25);  break;
        case 6: m_Rate.Setcycle(20);  break;
        case 7: m_Rate.Setcycle(15);  break;
        case 8: m_Rate.Setcycle(10);  break;
        case 9: m_Rate.Setcycle(5);   break;
        default: m_Step = -1; m_Rate.Setcycle(speed); 
            break;
        }
    }
    */


    //=============================================================================
    //  Name : DragTo()
    //  Desc : compute new drag to situs ( use for mouse drag )
    //=============================================================================
    void Element2d::DragTo( GVertex mpos )
    {
        //spos = spos - Norm(); // change to map position
        //GVertex destpt( mpos.x - m_tmp_focus_elm_relative_pos.x, mpos.y - m_tmp_focus_elm_relative_pos.y );
        //m_Route.push_back( destpt );
        //Pos() = m_Route.back();
        Pos() = mpos - m_tmp_focus_elm_relative_pos;
        return ;
    }


    //=============================================================================
    //  Name : Rect()
    //  Desc : compute object ambit in screen site ( norm = (0, 0) )
    //=============================================================================
    LG::Rect Element2d::Rect( void )
    {
        CPIcon* img = Image();
        if( img == 0 )
        {
            LG::Rect rect;
            return rect;
        }
        return img->Rect( Pos() );
    }

    //=============================================================================
    //  Name : Screen_Rect()
    //  Desc : compute object ambit in map site
    //=============================================================================
    LG::Rect Element2d::ScreenRect( void )
    {
        //GVertex pt  = ScreenPos();
        return Image()->Rect( ScreenPos() );

        //LG::Rect rect = Image()->Rect(Pos());
        //LG::Rect opporect(rect.left  - pt.x, rect.top    - pt.y, 
        //              rect.right - pt.x, rect.bottom - pt.y);
        //return opporect;
    }

    //=============================================================================
    //  Name : Image_Rect()
    //  Desc : compute image ambit in screen site ( norm = (0, 0) )
    //=============================================================================
    LG::Rect Element2d::ImageRect( void )     //�ϧνd��
    {
        CPIcon* img = Image();
        return ( img == 0 ) ?
               LG::Rect( 0, 0, 0, 0 ) :
               img->Image_Rect( Pos() );
    }


    //=============================================================================
    //  Name : Image_Screen_Rect()
    //  Desc : compute image ambit in screen site ( norm = (0, 0) )
    //=============================================================================
    LG::Rect Element2d::ScreenImageRect( void )     //�ϧνd��
    {
        CPIcon* img = Image();
        return ( img == 0 ) ?
               LG::Rect( 0, 0, 0, 0 ) :
               img->Image_Rect( ScreenPos() );
    }


    //=============================================================================
    //
    // �P�_�@�I�O�_�@�b��ڽd��
    //=============================================================================
    Pbool Element2d::IsCollision( GVertex mpos )
    {
        //int nID = (*(*m_AnimTable)[m_ActPtr])();
        //if(nID == -1)               //�S���Ϥ�
        //  return false;
        CPIcon* img = Image();
        if( img == 0 )
            return m_Focus = _LOST_FOCUS;
        return m_Focus = img->Collision( mpos, Pos().x, Pos().y );
    }


    //=============================================================================
    //
    // �P�_�@�I�O�_�@�b�ϧνd��
    //=============================================================================
    Pbool Element2d::IsImageCollision( GVertex mpos )
    {
        CPIcon* img = Image();
        if( img == 0 )
            return m_Focus = _LOST_FOCUS;
        return m_Focus = img->CollisionImage( mpos, Pos().x, Pos().y );
    }


    //=============================================================================
    //
    // ��Ĳ�I��
    //=============================================================================
    Pbool Element2d::IsCollision( Element2d* srcobj )
    {
        /*
        int vertex_count = ( ( srcobj->Image()->Ambit_Shape ) & ( 0XF0 ) );
        for( int i = 0; i < vertex_count; i++ )
        {
            //GVertex pt = 
            //Image()->Collision( 
        }
        CPIcon *img = Image();
        if( srcobj == 0 )
            return FALSE;
        if(img == 0)
            return m_Focus = _LOST_FOCUS;
        return m_Focus = img->Is_Collision( srcobj->Image(), Pos().x, Pos().y );
        */

        /*
        LG::Rect Myrange = Map_Rect() ;
        LG::Rect Otrange = Otrange ;
           if ((( (Myrange.left - Myrange.right) + (Otrange.left - Otrange.right) ) > abs(Otrange.right - Myrange.left)) ||
               (( (Myrange.bottom - Myrange.top) + (Otrange.bottom - Otrange.top ) ) > abs(Otrange.bottom - Myrange.top)))
        {
            return true;
        }
           */
        return FALSE;
    }


    //=============================================================================
    //  Name : Go_Path()
    //
    //=============================================================================
    void Element2d::GoRoute( void )
    {
        if( m_Route.empty() )
            return;

        if( m_StepRate.Interval() == -1 )
        {
            Pos() = m_Route();
            if( m_Route.back() != Pos() )
            {
                m_Route++;
                ChangeMotion( m_NowAct, m_Route() );
            }else
                m_Route.clear();
        }
        return;
    }

    //=============================================================================
    //  Name : search_path()
    //
    //=============================================================================
    int Element2d::FindRoute( GVertex from, GVertex to )
    {
        if( ( !Moveable ) || ( m_Step == 0 ) )
        {
            m_Route.push_back( to );
            m_Route.GoBegin();
            return -1;
        }

        //m_Route.clear();  
        //�T�w�V�q�����q
        int Dx          = to.x - from.x;
        int Dy          = to.y - from.y;


        //�p��W�q��
        int steps       = ( int )
                          ( floor( ( double ) max( abs( Dx ), abs( Dy ) ) ) +
                            1 ) ;

        double dx_step  = ( ( double ) Dx / ( double ) steps )  ;
        double dy_step  = ( ( double ) Dy / ( double ) steps )  ;

        float x         = from.x + ( ( float ) dx_step* m_Step );// first must can't now situs;
        float y         = from.y + ( ( float ) dy_step* m_Step ); 


        steps = ( steps / m_Step );// protect for walk over 
        for( int u = 0;u < steps;u++ )
        {
            m_Route.push_back( GVertex( ( int ) floor( x ),
                                         ( int ) floor( y ) ) );
            x = x + ( ( float ) ( dx_step ) * ( float ) ( m_Step ) );
            y = y + ( ( float ) ( dy_step ) * ( float ) ( m_Step ) );
        }

        //m_Route.push_back( to );
        m_Route.GoBegin();
        return steps;
    }

    //============================================================================================
    //  Name : Proc();
    //  Desc : judgment event
    //============================================================================================
    int Element2d::Proc( LG::Point point, Puint uMsg, Puint wParam )
    {
        point = point - Norm(); // change to map position

        if( uMsg == WM_LBUTTONDOWN )    //prepare to start drag
            m_tmp_focus_elm_relative_pos = point - Pos();
        else if( uMsg == WM_LBUTTONUP ) //prepare to end drag
            m_tmp_focus_elm_relative_pos( 0, 0 );

        //if( ( uMsg != WM_NULL ) && ( isCollision(point) ) && ( Enable ) )
        if( ( uMsg != WM_NULL ) && ( IsCollision( point ) ) )
        {
            switch( uMsg )
            {
            case WM_MOUSEMOVE:
            {
                short LMouseAct = GetAsyncKeyState( VK_LBUTTON );
                if( LMouseAct )
                {
                    if( ( Dragable ) &&
                        ( m_tmp_focus_elm_relative_pos.x != 0 ) &&
                        ( m_tmp_focus_elm_relative_pos.y != 0 ) &&
                        ( ( m_NowAct == PE_LBUTTONDOWN ) ||
                          ( m_NowAct == PE_MOUSEDRAG ) ) )//begin drag
                    {
                        DragTo( point );
                        OnDrag( point );
                        return m_NowAct = PE_MOUSEDRAG; //Drag Act
                    }else if( m_NowAct != PE_LBUTTONUP )  //button down and slip over
                    {
                        if( Enable )
                        {
                            OnLMouseDown( wParam, point );
                        }
                        return m_NowAct = PE_LSLIPDOWN;//Down Act
                    }
                }
                if( Enable )
                {
                    OnMouseOver( wParam, point );
                }
                return m_NowAct = PE_MOUSEOVER; //Move Act
            }

            case WM_LBUTTONDOWN:
            {
                if( Enable )
                {
                    OnLMouseDown( wParam, point );
                }
                return m_NowAct = PE_LBUTTONDOWN;
            }
            case WM_LBUTTONUP:
            {
                if( Enable )
                {
                    OnLMouseUp( wParam, point );
                }
                return m_NowAct = PE_LBUTTONUP;
            }
            case WM_LBUTTONDBLCLK:
            {
                if( Enable )
                {
                    OnLDBClick( wParam, point );
                }
                return m_NowAct = PE_LBUTTONDOWN;
            }
            case WM_RBUTTONDOWN:
            {
                if( Enable )
                {
                    OnRDBClick( wParam, point );
                }
                return m_NowAct = PE_RBUTTONDOWN;
            }

            case WM_RBUTTONUP:
            {
                if( Enable )
                {
                    OnRMouseUp( wParam, point );
                }
                return m_NowAct = PE_RBUTTONUP;
            }
            case WM_KEYDOWN:
            {
                if( Enable )
                {
                    OnKeyDown( wParam );
                }
                return m_NowAct = PE_KEYDOWN;
            }
            case WM_KEYUP:
            {
                if( Enable )
                {
                    OnKeyUp( wParam );
                }
                return m_NowAct = PE_KEYUP;
            }
            default:
            {
                return PE_MOUSEOVER;
            }
            }
        }else if( ( m_NowAct == PE_MOUSEDRAG ) &&
                  ( Dragable )/*&& (uMsg == WM_MOUSEMOVE) */ )//outside area but still drag
        {
                m_Focus = _GET_FOCUS;
                DragTo( point );
                OnDrag( point );;
                return PE_MOUSEDRAG;
        }else //outside area
        {
            m_Focus = _LOST_FOCUS;
            if( m_AnimTable.GetNowSeqID() >= PRE_LOAD_SEQUENCE_COUNT )
                SequenceRemove( m_AnimTable.GetNowSeqID() );
            OnMouseNull();
            return m_NowAct = PE_NULL;
        }
    }



    //=============================================================================
    //
    // judgment m_NowAspect use slope
    //=============================================================================
    int Element2d::JudgDirection( GVertex destpt )
	//int Element2d::Faceto( GVertex destpt )
    {
        switch( GetMaxAspect() )
        {
			case _1_Direction:
			{
				//return win_coordinate_axis_slope_8dir( Pos(), destpt );
				return dir8_by_slope( GVertex( Pos().x, -Pos().y ),
									  GVertex( destpt.x, -destpt.y ) );;
			}

			case _4_Direction:
			{
				//int ret = win_coordinate_axis_slope_4dir( Pos(), destpt );
				return dir4_by_slope( GVertex( Pos().x, -Pos().y ),
									  GVertex( destpt.x, -destpt.y ) );;
			}
			default://_8_Direction
			{
				////int ret = win_coordinate_axis_point_8dir( Pos(), destpt );
				//int ret = win_coordinate_axis_slope_8dir( Pos(), destpt );
				return dir8_by_slope( GVertex( Pos().x, -Pos().y ),
									  GVertex( destpt.x, -destpt.y ) );;
			}
        }
        return -2;
    }

	//=============================================================================
    //
    // judgment m_NowAspect use slope
    //=============================================================================
    void Element2d::ChangeMotion( UINT act, GVertex destpt )
	{
		m_NowAct = act;
		int ret = JudgDirection( destpt );
		if( ret >= 0 )
			m_NowAspect = ret;
		m_AnimTable.Change_Sequ_Iterator( m_NowAct, GetMaxAspect(), m_NowAspect );
	}

};//namespace GE

