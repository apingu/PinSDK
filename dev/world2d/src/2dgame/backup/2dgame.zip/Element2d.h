//Element.h header file of Element.cpp
//
//
//
//
//
//
//
//
//
//
//
//
//                                               Copyright    (C)    1999    Pin
//

#ifndef ELEMENT2D_H
#define ELEMENT2D_H


#include "Resource2d.h"
#include <HPelem.h>

namespace GE
{
    //-----------------------------------------------------------------------------
    // Name: class Element2d
    // Desc: base class in game world
    //------------------------------------------------------------------------------
    class Element2d : public Resource2d
    {
		int                 JudgDirection( GVertex destpt );

    protected:
        
		void                ChangeMotion( UINT act, GVertex destpt );
		
        void*               m_parent;
        void*               m_master;

    public:

        Element2d();
        ~Element2d();

        virtual void        Release( void );

        int                 CompareOrder( Element2d& element );

        void                SetElemData( H2DPELEM  data );
        void                GetElemData( H2DPELEM* data );

        //�ɮ�
        virtual int         Load( const char* elmpath );        //open pelm
        void                Save( const char* elmpath );

        void                Read( const char* filepath,
                                  int size,
                                  int NO,
                                  int Type = 0 );            //read data functon for 3tj


        virtual Element2d*  breed( void );
        virtual Element2d&  operator=( Element2d element );


        void                GoRoute( void );
        int                 FindRoute( GVertex from, GVertex to );
        virtual void        DragTo( GVertex new_norm );


        //�P�_
        virtual int         Proc( LG::Point point, Puint uMsg, Puint wParam );
        virtual BOOL        IsCollision( GVertex mpos );
        virtual BOOL        IsImageCollision( GVertex mpos );
        virtual BOOL        IsCollision( Element2d* srcobj );              //�I��

        LG::Rect            Rect( void );                //�޿�d��
        LG::Rect            ImageRect( void );           //�޿�d��
        LG::Rect            ScreenRect( void );          //����W���d��
        LG::Rect            ScreenImageRect( void );     //����W���d��
        UINT                ImageWidth( void )  { return ( Image() == 0 ) ? 0 : Image()->width;  } //�e
        UINT                ImageHeight( void ) { return ( Image() == 0 ) ? 0 : Image()->height; } //��


        //�ƥ�
        virtual void OnMouseNull( Pvoid ) {};
        virtual void OnMouseOver( int key, LG::Point point ) {};
        virtual void OnLMouseDown( int key, LG::Point point ) {};
        virtual void OnRMouseDown( int key, LG::Point point ) {};
        virtual void OnLMouseUp( int key, LG::Point point ) {};
        virtual void OnRMouseUp( int key, LG::Point point ) {};
        virtual void OnLDBClick( int key, LG::Point point ) {};
        virtual void OnRDBClick( int key, LG::Point point ) {};
        virtual void OnDrag( LG::Point point ) {};
        virtual void OnDragDrop( LG::Point point ) {};
        virtual void OnKeyDown( int key ) {};
        virtual void OnKeyUp( int key ) {};
    };

    typedef Element2d Elem2d;
};//namespace GE



#endif
