// Body.h header file of body.cpp
//
//
//
//
//
//
//
//
//
//
//
//
//                                               Copyright    (C)    1999    Pin
//
#ifndef SPRITE2D_H
#define SPRITE2D_H


#include <Direction2d.h>
#include <Graphic3d.h>
#include <Gene.h>
#include <tString.h>
#include <PTimer.h>
#include <PtrDlist.tl>
#include <SmartPointer.tl>


#define _IMAGE_PLAY_ON_INTERVAL_TIMES  0
#define _IMAGE_STOP                   -1
#define _IMAGE_PLAY_ONE_TIMES         -2
#define _IMAGE_PLAY_N_TIMES           -3

#define _GET_FOCUS  1
#define _LOST_FOCUS 0


typedef LG::Point GVertex;

namespace GE
{
    //-----------------------------------------------------------------------------
    // Name: class Sprite2d
    // Desc: to store base value use for game element
    //------------------------------------------------------------------------------
    //extern GVertex _Map_norm;      //�Ҧb�a�Ϫ�����I
    class Sprite2d : public CPGene
    {
    protected:

        UINT                m_Init_Step;
        UINT                m_Init_Clockcycle;
		UINT                m_AngleOfView;               //����
        short               m_MaxAspect;                 //me����V�� 8 or 4 or 16 ......

        GVertex             m_tmp_focus_elm_relative_pos;//temp for drag
        int                 m_tmp_distance;              //�s��p�Ⲿ�ʶZ��


        CPTimer             m_StepRate;
        CPTimer             m_FlipRate;                  //image refresh rate

        MEM::String         m_fname;
        DWORD*              m_ReferCount;                //�Q�ƻs���ƶq


        GVertex             m_Position;                  //�a�Ϧ�m
        short               m_NowAct;                    //�]�w�ثe���ʧ@(��, ����, ..........)
        short               m_NowAspect;                 //�ثe�ʧ@����V
        short               m_NowDeedStatus;             //****�ثe�ʧ@���A(0 - ����, 1 - �ǳ�, 2 - �}�l�ʧ@, 3 - �ʧ@�i�椤, 4 - �����ʧ@);
        short               m_NowFrameStatus;            //�ثe�ϧμ��񪺪��A( ����, 1��, n��, ����϶���, �ϧνs�� )


        int                 m_Collision;                 //�I������Flag
        BOOL                m_Focus;                     //�J�IFlag


        UINT                m_Step;         //****move distance


        PtrDlist<GVertex>   m_Route;        //****�樫���|  push to protected screen pos


    public :


        Sprite2d();
        ~Sprite2d();


        virtual void        Release( void );
        Pcstr               filename( void ) { return ( Pstr ) m_fname; }

        GVertex&            Pos( void )      { return m_Position; }
        GVertex             Goal( void )     { return m_Route.back(); } //return where will move to 
        virtual GVertex     ScreenPos( void ){ return m_Position + Norm(); }
        virtual GVertex     Norm( void )     { return ( m_pScreenDatum == 0 ) ? GVertex( 0, 0 ) : ( *m_pScreenDatum ); }

        void                Restore_Speed( void );
        void                Initiate( void );

        BOOL                IsFocus( void )  { return m_Focus; }
        UINT&               GetStep( void )  { return *( &m_Step ); }
        short               GetMaxAspect( void ) { return m_MaxAspect; }
        int                 GetNowDeedStatus( void ) { return m_NowDeedStatus; }
        short               GetNowFrameStatus( void ){ return m_NowFrameStatus; }

	public:

        //std::vector<Sprite2d*>    m_Target;
        GVertex*            m_pScreenDatum;
        void*               m_Descriptor; 


        BOOL                Enable;          //is element enable    ���� 
        BOOL                Visible;         //is element visible   �q��
        BOOL                Dragable;        //is element dragable  �즲 
        BOOL                Moveable;        //is elelment moveable ����


    };
};//namespace


#endif
