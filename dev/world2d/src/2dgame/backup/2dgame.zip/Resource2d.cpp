// Intellect.cpp game element compute judege class
//
//
//
//
//
//
//
//
//
//
//
//
//
//                                               Copyright    (C)    1999    Pin
//
#include "Resource2d.h"
#include <PFile.h>

namespace GE
{
//#define ANIM_ID( a, d )           ( ( a * GetMaxAspect() ) + d )
#define ACIMTABLESEQ( i )         (*(*m_Sequence)[m_Now_Seq_Ptr])
    //CPVertex _Map_norm;      //�Ҧb�a�Ϫ�����I

    ///////////////////////////////////////////////////////////////////////////////////////////////
    //  AnimTable


    //=============================================================================
    //  Name : 
    //  Desc : construct
    //=============================================================================
    AnimTable::AnimTable()
    {
        //m_NowAct         = 0;
        m_Now_Seq_Ptr = 0;
        m_Sequence = 0;
        //MaxAspect()   = 0;
        //lp_Now_Frame      = 0;
        //m_MaxAspect  = 1;
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    AnimTable::~AnimTable()
    {
        Release();
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void AnimTable::operator++( int )
    {
        //lp_Now_Frame ++;
        ACIMTABLESEQ( m_Now_Seq_Ptr )++;
        return;
    }

    int AnimTable::operator()( void )
    {
        return ( m_Sequence == NULL ) ? 0 : ACIMTABLESEQ( m_Now_Seq_Ptr )();
    }

    Sequence* AnimTable::operator[]( int actno )
    {
        return ( *m_Sequence )[ actno ];
    }

    AnimTable& AnimTable::operator=( AnimTable& animtable )
    {
        Release();
        //m_file_offSet = AToffSet;
        m_Sequence = new Array<Sequence*>;

        int StepImageCount  = 0; //check var all action step count must eq image count;
        m_Sequence->allot( animtable.SequenceCount() );
        for( int aci = 0;aci < animtable.SequenceCount();aci++ )
        {
            ( *m_Sequence )[ aci ] = new Sequence;
            for( int acsi = 0;acsi < animtable.FrameCount( aci );acsi++ )
            {
                ( *m_Sequence )[ aci ]->push_back( animtable.FrameID( aci,
                                                                      acsi ) );
                StepImageCount ++;
            }
            ( *m_Sequence )[ aci ]->GoBegin();
        }

        /*
        if( empty() )
            lp_Now_Frame.clear();
        else
            lp_Now_Frame = (*m_Sequence)[0]->begin();
            */

        return *this;
    }

    int AnimTable::empty( void )
    {
        return ( m_Sequence == NULL ) ? 1 : 0;
    }

    int AnimTable::IsNowAnimEnd( void )
    {
        return ( *m_Sequence )[ m_Now_Seq_Ptr ]->isEnd();//( (*m_Sequence)[m_Now_Seq_Ptr]->end() == lp_Now_Frame );
    }

    int AnimTable::SequenceCount( void )
    {
        if( m_Sequence == NULL )
            return 0;
        return m_Sequence->size();
    }

    int AnimTable::GetNowSeqID( void )
    {
        return m_Now_Seq_Ptr;
    }

    int AnimTable::GetNowFrameOrder( void )
    {
        return ( *m_Sequence )[ m_Now_Seq_Ptr ]->GetIndex();
    }

    int AnimTable::FrameID( int act, int step )
    {
        return ( *( *m_Sequence )[ act ] )[ step ];
    }

    int AnimTable::FrameCount( void )
    {
        return ( *m_Sequence )[ m_Now_Seq_Ptr ]->size();
    }

    int AnimTable::FrameCount( int AnimNo )
    {
        return ( *m_Sequence )[ AnimNo ]->size();
    }


    //=============================================================================
    //  Name : Release
    //  Desc :
    //=============================================================================
    void AnimTable::Release( void )
    {
        if( m_Sequence == NULL )
            return;

        for( UINT i = 0 ;i < m_Sequence->size();i++ )
        {
            if( ( *m_Sequence )[ i ] != 0 )
                ( *m_Sequence )[ i ]->clear();
        }
        m_Sequence->release_element();
        m_Sequence->clear();

        SAFE_DELETE( m_Sequence );
    }


    //=============================================================================
    //  Name : Load
    //  Desc :
    //=============================================================================
    int AnimTable::Load( const char* path )
    {
        char msg[ _MAX_MSG ];
        CPFile pf;

        if( ( pf.open( path, "rb" ) ) == NULL )
        {
            sprintf( msg, "open action table file %s failure -_-b", path );
            DebugMessage( msg, "AnimTable" );
            return pf.ferrno();
        }

        Release();
        //m_file_offSet = AToffSet;
        m_Sequence = new Array<Sequence*>;

        int StepImageCount  = 0; //check var all action step count must eq image count;

        pf.seek( 0 );
        Pword ActCount  = 0;
        pf.read( &ActCount, sizeof( ActCount ), 1 );

        m_Sequence->allot( ActCount );
        for( int aci = 0;aci < ActCount;aci++ )
        {
            Pword ActStepCount  = 0;
            pf.read( &ActStepCount, 1, sizeof( ActStepCount ) );
            ( *m_Sequence )[ aci ] = new Sequence;
            for( int acsi = 0;acsi < ActStepCount;acsi++ )
            {
                Pdword StepNo   = 0;
                pf.read( &StepNo, 1, sizeof( StepNo ) );
                //fread(&StepNo, 1, sizeof(StepNo), pf);
                ( *m_Sequence )[ aci ]->push_back( StepNo );
                StepImageCount ++;
                ( *m_Sequence )[ aci ]->GoBegin();
            }
        }

        //lp_Now_Frame = empty()? 0 : (*m_Sequence)[0]->begin();

        return 1;
    }


    //=============================================================================
    //  Name : Save
    //  Desc :
    //=============================================================================
    void AnimTable::Save( const char* path )
    {
        CPFile pf;
        //FILE* pf;

        if( ( pf.open( path, "wb" ) ) == NULL )//�}�ɦp�G-1�h���ѡA�Ǧ^-1
        {
            char msg[ _MAX_MSG ];
            sprintf( msg, "save action table file %s failure -_-b", path );
            DebugMessage( msg, "AnimTable" );
            return;
        }

        Pword as= SequenceCount();
        pf.write( &as, sizeof( Pword ), 1 );  //write act count

        for( Pword Act = 0;Act < as;Act++ )
        {
            Pword acts  = FrameCount( Act );
            pf.write( &acts, sizeof( Pword ), 1 );  //write step count

            for( int Step = 0;Step < FrameCount( Act );Step++ )
            {
                int ActStep = FrameID( Act, Step );
                pf.write( &ActStep, sizeof( Pdword ), 1 );
            }
        }
        pf.close();
    }


    //=============================================================================
    //  Name : Change_Sequ_Iterator
    //  Desc :
    //=============================================================================
    void AnimTable::Change_Sequ_Iterator( UINT Act, UINT MaxAct, UINT dir )
    {
		//Act = ( Act * GetMaxAspect() ) + dir;
        //int act = Sequence_ID(Act, MaxAspect());
        if( ( m_Sequence == NULL ) || ( m_Now_Seq_Ptr == Act ) )  //�S���ʧ@�� //�w�g�b�o�Ӱʧ@�W
            return;

		/////////////////////
		//UINT LastAct = ( m_Now_Seq_Ptr * MaxAct ) + dir;
		UINT PlayAct = ( Act * MaxAct ) + dir;
		/////////////////////
        if(  PlayAct > static_cast<int>( m_Sequence->size() ) ) //�S���o�Ӱʧ@
		{
            PlayAct = dir;
		    //Act = 0;
		}
        //m_ImageCounter = 0;
		( *m_Sequence )[ m_Now_Seq_Ptr ]->GoBegin();
        m_Now_Seq_Ptr = PlayAct;
        ( *m_Sequence )[ m_Now_Seq_Ptr ]->GoBegin();
        //lp_Now_Frame = (*m_Sequence)[Act]->begin();
        return;
    }


    //////////////////////////////////////////////////////////////////////////////////////////////
    // sprite class

    //=============================================================================
    //  Name : 
    //  Desc : constructor
    //=============================================================================
    Resource2d::Resource2d()
    {
        //m_ReferCount   = 0;
		m_pIconList=NULL;
        m_ImageCounter = 0;
        m_ReadImageCount = 0;
        m_InitReadImageCount = 0;
        m_pIconList.release_element();
        m_pIconList.clear();
    }


    //=============================================================================
    //  Name : 
    //  Desc : disturctor
    //=============================================================================
    Resource2d::~Resource2d()
    {
        m_AnimTable.Release();

        if( m_ReferCount == 0 )
            return;

        if( ( *m_ReferCount ) == 1 )
            ImageListRelease();
        ( *m_ReferCount )--;
    }


    //=============================================================================
    //  Name : ImageLoad()
    //  Desc :
    //=============================================================================
    Perror Resource2d::Load( const char* path )
    {
        CPFile pf;
        if( pf.open( path ) == NULL )
        {
            char msg[ _MAX_MSG ];
            sprintf( msg,
                     "allot image box file %s failure -_-b",
                     ( char* ) m_fname );
            DebugMessage( msg, "Resource2d" );
            return pf.ferrno();
        }

        ImageListReAllot( pf.FileCount() );

        int load_count  = PRE_LOAD_SEQUENCE_COUNT;
        load_count = min( m_AnimTable.SequenceCount(), load_count );

        for( int c = 0;c < load_count;c++ )
            SequenceInsert( c );

        m_InitReadImageCount = m_ReadImageCount;

        return pf.ferrno();
    }


    //=============================================================================
    //  Name : Clear_Counter()
    //  Desc :
    //=============================================================================
    void Resource2d::Save( const char* path )
    {
        //char ILpath[_MAX_PATH];
        //_makepath( ILpath, drive, dir, "I", "L" );

        CPFile pf;

        vector<const char*> Imagefpath;
        for( UINT i = 0;i < m_pIconList.size();i++ )
            Imagefpath.push_back( m_pIconList[ i ]->filename() );


        if( pf.open( path, "wb" ) == NULL )
        {
            char message[ _MAX_MSG ];
            sprintf( message, "save file %s failure !!!", path );
            DebugMessage( message, "CPElement" );
            return;
        }

        pf.Packfiles( Imagefpath );
        pf.close();
    }


    //=============================================================================
    //
    //
    //=============================================================================
    int Resource2d::ImageListReAllot( UINT size )
    {
        // clear exist image first
        ImageListRelease();
        m_pIconList.allot( size );
        m_ReadImageCount = 0;
        m_InitReadImageCount = 0;
        return 1;
    }



    //=============================================================================
    //  Name : ImageList_Release()
    //  Desc : 
    //=============================================================================
    void Resource2d::ImageListRelease( void )
    {
        if( m_pIconList.empty() )
            return;
        m_pIconList.release_element();
        m_pIconList.clear();
        m_ReadImageCount = 0;
        m_InitReadImageCount = 0;
        return;
    }


    //=============================================================================
    //  Name :
    //  Desc : release extern load image memory
    //=============================================================================
	/*
    void Resource2d::InitReadAnimCount( void )
    {
        if( m_InitReadImageCount < m_ReadImageCount )
        {
            for( UINT i = m_InitReadImageCount;i < m_pIconList.size();i++ )
            {
                if( m_pIconList[ i ] != NULL )
                {
                    delete m_pIconList[ i ];
                    m_pIconList[ i ] = NULL;
                    m_ReadImageCount--;
                    if( m_InitReadImageCount == m_ReadImageCount )
                        return;
                }
            }
        }
    }
	*/


    //=============================================================================
    //    Name : Sequence_Insert()
    //    Desc : Read action sequence from m_fname and return read count
    //=============================================================================
    size_t Resource2d::SequenceInsert( UINT Seq_No )
    {
        int seqcount= m_AnimTable.SequenceCount();
        if( ( seqcount == 0 ) || ( Seq_No > seqcount ) )
            return -1;

        //int  readcount = 0;
        //uPpFile ppf = pf.OpenPpFile(filepath);
        for( int i = 0;i < m_AnimTable.FrameCount( Seq_No );i++ )
        {
            Image( m_AnimTable.FrameID( Seq_No, i ) );
        }
        return m_ReadImageCount;
    }



    //=============================================================================
    //  Name : Sequence_Erase()
    //  Desc : erase sequence image form imagebox
    //=============================================================================
    void Resource2d::SequenceRemove( UINT Seq_No )
    {
        if( ( m_AnimTable.empty() ) || ( m_pIconList.empty() ) )
            return;

        for( UINT i=0; i<m_AnimTable[ Seq_No ]->size(); i++ )
        {
            int ImgNo   = m_AnimTable.FrameID( Seq_No, i );
            if( m_pIconList[ ImgNo ] != 0 )
            {
                delete m_pIconList[ ImgNo ];
                m_pIconList[ ImgNo ] = 0;
                m_ReadImageCount--;
            }
        }
        return ;
    }


    //=============================================================================
    //  Name : Perform()
    //  Desc :
    //=============================================================================
    void Resource2d::Do( int Act )
    {
        m_NowAct = Act;
        m_AnimTable.Change_Sequ_Iterator( Act, GetMaxAspect(), m_NowAspect );
        return;
    }


    //=============================================================================
    // ����@�������ʵe
    //
    //  
    //                      -1 ���j�ɶ�
    //  �s�򼷩�ǤJ -1     -2 �����@��    �ʧ@������
    //  ���Ƽ���ǤJ  n     -3 ���� n��    �ʧ@������
    //=============================================================================
    int Resource2d::UpdateAnim( int count )
    {
        if( ( m_AnimTable.empty() ) ||
            ( ( m_ImageCounter >= count ) && ( count != -1 ) ) )
            return m_NowFrameStatus = _IMAGE_STOP;

        if( m_FlipRate.Interval() == -1 )
        {
            m_AnimTable++;
            if( m_AnimTable.IsNowAnimEnd() )
            {
                if( count == -1 )//�s�򼷩񪺪��A�U�A�C�����@�^
                    return m_NowFrameStatus = _IMAGE_PLAY_ONE_TIMES;
                else
                {
                    m_ImageCounter++;
                    return m_NowFrameStatus = _IMAGE_PLAY_N_TIMES;//already play n times
                }
            }
            return m_NowFrameStatus = m_AnimTable.GetNowFrameOrder();//ActionList(act)->Index();
        }
        return m_NowFrameStatus = _IMAGE_PLAY_ON_INTERVAL_TIMES;//no filp image to next
    }


    //=============================================================================
    //    Name : Image()
    //    Desc : return now image point
    //=============================================================================
    CPIcon* Resource2d::Image( void )         //singled image
    {
        if( ( m_pIconList.empty() ) || ( !Visible ) )
            return 0;

        UINT i  = m_AnimTable();
        if( m_pIconList[ i ] == NULL )
        {
			//�M���h���J������
			if( m_InitReadImageCount < m_ReadImageCount )
			{
				for( UINT i = m_InitReadImageCount;i < m_pIconList.size();i++ )
				{
					if( m_pIconList[ i ] != NULL )
					{
						delete m_pIconList[ i ];
						m_pIconList[ i ] = NULL;
						m_ReadImageCount--;
						if( m_InitReadImageCount == m_ReadImageCount )
							break;
					}
				}
			}

			//�w�����J��հʧ@�A�W�L�h�[�J�s�ϧ�
            SequenceInsert( m_AnimTable.GetNowSeqID() );  
        }
        return m_pIconList[ i ];
    }


    //=============================================================================
    //    Name : Image()
    //    Desc : return now image point
    //=============================================================================
    CPIcon* Resource2d::Image( UINT i )
    {
        if( m_pIconList.empty() )
            return NULL;

        if( m_pIconList[ i ] != NULL )
            return m_pIconList[ i ];

        char fname[ _MAX_PATH ];
        char nobuf[ 10 ];

        //****************************************************** may be have wrong?????
        m_pIconList[ i ] = new CPIcon;
        sprintf( fname,
                 "%s?%s|%s",
                 (char*)m_fname,
                 "I.L",
                 itoa( i, nobuf, 10 ) );
        if( m_pIconList[ i ]->Load( fname ) == 1 )
            m_ReadImageCount++;
        else  // if read image file failure write message to debug file
        {
            char msg[ _MAX_MSG ];
            sprintf( msg, "read image file %s failure !!!", fname );
            DebugMessage( msg, "Resource2d" );
        }

        return m_pIconList[ i ];
    }


    //=============================================================================
    //    Name : Animation()
    //    Desc : go next image and return it
    //=============================================================================
    CPIcon* Resource2d::Animation( int count )
    {
        int ret = UpdateAnim( count );
        return ( ret == _IMAGE_STOP ) ? 0 : Image();
    }

};//namespace GE


