//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
#ifndef ANIM_H
#define ANIM_H


#include <pdef.h>
#include <PtrDlist.tl>
typedef  PtrDlist<int>    Sequence;      //store action

namespace GE
{
    class Anim2d
    {
        UINT m_MaxDir;
        Sequence* m_Sequence;

    public:
        Anim2d();
        ~Anim2d();
        
        Perror Load( Pcstr filename );
        Perror Save( Pcstr filename );

    };
};


#endif
