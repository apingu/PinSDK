//Surface.cpp base map class
//
//
// static -->> - (ID) - 2
//
//
//
//
//
//
//
//
//
//                                               Copyright    (C)    1999    Pin
//
#include "Scene2d.h"
#include <PFile.h>
#include <aIntersect.h>




namespace GE
{

    ///////////////////////////////////////////////////////////////////////////////
    // surface class


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    Scene2d::Scene2d():GameSpace()
    {
        m_pRender = NULL;
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    Scene2d::~Scene2d()
    {
        //DeleteAllElem();
    }




	//=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
	void Scene2d::PasteTerrain( LGB::CMemCanvas* canvas )
	{
		if( ( m_pRender == NULL )  && ( m_pRender->GetWidget() == NULL ) )
			return;
		for( UINT i=0; i<m_pSectorList.size(); i++ )
		{
			LG::Point situ = m_pSectorList[i];
			Element2d* elem = (Element2d*)GetCellData( situ.x, situ.y );
            if( (elem != NULL) && (elem->Visible) )
                m_pRender->Blit( elem->Animation(),
				                 elem->ScreenPos(), canvas );
		}
	}


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Scene2d::InsertEntity( Element2d* elem )
    {
        elem->m_pScreenDatum = &m_ScreenDatum;
		elem->m_Descriptor = GameSpace::InsertEntity( elem );
        return;
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Scene2d::RemoveEntity( Element2d* elem )
    {
        GameSpace::RemoveEntity( elem->m_Descriptor );
        elem->m_pScreenDatum = NULL;
        elem->m_Descriptor = NULL;
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Scene2d::SetFocusEntity( Element2d* elem )
	{
		if( elem == NULL )
			GameSpace::SetFocusEntity( NULL );
		else
		    GameSpace::SetFocusEntity( elem->m_Descriptor );
		return;
	}

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    Element2d* Scene2d::GetFocusEntity( void )
	{
		return (Element2d*)GameSpace::GetFocusEntity();
	}


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Scene2d::SetRender( LGB::VMC* vmc )
    {
        m_pRender = vmc;
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    LGB::VMC* Scene2d::GetRender( void )
    {
        return m_pRender;
    }

	
	/*
    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Scene2d::SetFocusElem( Element2d* elem )
    {
        if( elem != NULL )
            SetFocusEntity( elem->m_Descriptor );
        else
            SetFocusEntity( NULL );
        return;
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    Element2d* Scene2d::GetFocusElem( void )
    {
        return ( Element2d * ) GetFocusEntity();
    }
	*/

	/*
    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Scene2d::PasteEntity( int i, CPIcon* canvas )
    {
        if( m_pRender == NULL )
            return;

        if( m_pRender->GetWidget() != NULL )
            m_pRender->Blit( ( ( Element2d * ) Entity( i ) )->Animation(),
                             ( ( Element2d * ) Entity( i ) )->ScreenPos(),
                             canvas );


        return;
    }

    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
    void Scene2d::PasteBackGround( CPIcon* canvas )
    {
        if( m_pRender == NULL )
            return;
        if( ( Visible ) && ( m_pRender->GetWidget() != NULL ) )
            m_pRender->AlphaBlit( Animation(), ScreenPos(), canvas );
        return ;
    }


    //=============================================================================
    //  Name : Flip_Scene()
    //  Desc : exchange two scene
    //=============================================================================
    void Scene2d::Flip_Scene( CPIcon* canvas, const char* path, int offSet )
    {
    }


    //=============================================================================
    //  Name : Drag_To()
    //  Desc : compute new drag to situs ( use for mouse drag )
    //=============================================================================
    void Scene2d::DragTo( GVertex mpos )
    {
        Element2d::DragTo( mpos );
        //GVertex offSet( new_norm.x - m_Situs.x, new_norm.y - m_Situs.y );
        //m_Situs = new_norm;

        mpos = mpos - Pos();  // because in scene Norm == ( 0 , 0 )
        for( Puint i = 0;i < EntityCount();i++ )
        {
            ( ( Element2d * ) Entity( i ) )->DragTo( mpos );
        }

        //Norm() = m_Situs;
    }


    //=============================================================================
    //  Name : Scroll_To()
    //  Desc : compute element situs when map scroll ( use for keydown )
    //=============================================================================
    void Scene2d::Scroll_To(GVertex new_norm)
    {
        //GVertex offSet(new_norm.x - m_Situs.x, new_norm.y - m_Situs.y);
        m_Situs = new_norm;
        for(int i = 0; i < Unit_Count(); i++)
        {
            ( (Element2d*)m_pUnitSeqs[i] )->Scroll_To(m_Situs);
        }
        //m_Situs   = new_norm;
        //Norm() = new_norm;
        return;
    }



    //========================================================================================
    //  Name : Load_BG()
    //  Desc : load a elem file to be background 
    //========================================================================================
    int Scene2d::LoadBackGround( const char* path )
    {
        //CPFile pf(path, "rb");
        return Element2d::Load( path );
    }


    //=============================================================================
    //  Name : 
    //  Desc :
    //=============================================================================
#define _MAP_RECT_LIMIT_ 100

    void Scene2d::Collide_Scroll( POINT point )
    {
        if( m_pRender->GetWidget() == NULL )
            return;

        GVertex mouse_pt;
        GetCursorPos( &mouse_pt );
        ScreenToClient( ( HWND )m_pRender->GetWidget(), &mouse_pt );

        LG::Rect client_rect;
        GetClientRect( ( HWND )m_pRender->GetWidget(), &client_rect );

        if( PA::Intersect::Test( &client_rect, &mouse_pt ) )
        {
            if( point.x < _MAP_RECT_LIMIT_ )
            {
                if( Norm().x < 0 )
                {
                    GVertex spt( Norm().x + 10, Norm().y ); 
                    Pos() = spt;

                    point.x = _MAP_RECT_LIMIT_;
                }
            }else if( point.x > m_pRender->GetWidth() - _MAP_RECT_LIMIT_ )
            {
                if( Norm().x > ( m_pRender->GetWidth() - ImageWidth() ) )
                {
                    GVertex spt( Norm().x - 10, Norm().y );
                    Pos() = spt;

                    point.x = m_pRender->GetWidth() - _MAP_RECT_LIMIT_;
                }
            }
            if( point.y < _MAP_RECT_LIMIT_ )
            {
                if( Norm().y < 0 )
                {
                    GVertex spt( Norm().x, Norm().y + 10 );
                    Pos() = spt;

                    point.y = _MAP_RECT_LIMIT_;
                }
            }else if( point.y > ( m_pRender->GetHeight() - _MAP_RECT_LIMIT_ ) )
            {
                if( Norm().y > ( m_pRender->GetHeight() - ImageHeight() ) )
                {
                    GVertex spt( Norm().x, Norm().y - 10 );
                    Pos() = spt;

                    point.y = m_pRender->GetHeight() - _MAP_RECT_LIMIT_;
                }
            }

            ClientToScreen( ( HWND ) m_pRender->GetWidget(), &point );
            SetCursorPos( point.x, point.y );
        }

        return;
    }
		*/

};//namespace GE

