//Intellect.h header file of Intellect.cpp
//
//
//
//
//
//
//
//
//
//
//
//
//        $(PIN_HOME),$(PIN_HOME)\Base,$(PIN_HOME)\Platform\Win32,$(PIN_HOME)\2DEngine,$(PIN_HOME)\Game,$(PIN_HOME)\2DGame
//
//                                               Copyright    (C)    1999    Pin

#ifndef RESOURCE2D_H
#define RESOURCE2D_H

#include <vector>
#include <math.h>

#include <Icon.h>
#include <Array.tl>
#include <Anim2d.h>
#include "Sprite2d.h"


#define _1_Direction    1
#define _4_Direction    4
#define _8_Direction    8


//passiveness status

//Active status
const int _STATUS_WATTING   = 0;
const int _STATUS_PREPARE   = 1;
const int _STATUS_BEGIN_DO  = 2;
const int _STATUS_DOING     = 3;
const int _STATUS_DO_FINISH = 4;
const int _STATUS_BEGIN_MOVE= 5;
const int _STATUS_MOVING    = 6;
const int _STATUS_ARRIVE    = 7;


const int AS_DESTORYSELF    = -1;
const int AS_STANDBY        = 0;
const int AS_WALK           = 1;
const int AS_ATTACK         = 2;
const int AS_DEFENCE        = 3;
const int AS_MAGIC          = 4;
const int AS_HITBACK        = 5;
const int AS_MAGICATTACK    = 6;

using namespace pt;



namespace GE
{
#define PRE_LOAD_SEQUENCE_COUNT    ( GetMaxAspect() * 2 )        //�w���s�J�X�հʧ@


    //////////////////////////////////////////////////////////////////////////////////////
    //   anim name class
    //-----------------------------------------------------------------------------
    // Name: class AnimTable
    // Desc: to store anim playing number table
    //------------------------------------------------------------------------------

    class AnimTable
    {
        short               m_Now_Seq_Ptr;    //�u�����V���ʧ@�ϧ�

    public:

        Array<Sequence*>*   m_Sequence;       //�ʧ@��

        AnimTable();
        ~AnimTable();

        int                 operator()( void );          //�ثe���V�ʧ@���s��
        void                operator++( int );
        Sequence*           operator[]( int actno );
        AnimTable&          operator=( AnimTable& animtable );

        void                Change_Sequ_Iterator( UINT Act, UINT MaxAct, UINT dir );

        int                 empty( void );
        int                 IsNowAnimEnd( void );

        int                 GetNowSeqID( void );
        int                 GetNowFrameOrder( void );       //�Ǧ^�ثe���ʧ@�O�b�ʵe�����ĴX�i

        int                 SequenceCount( void );          //�Ǧ^�@���h�ֺذʧ@
        int                 FrameCount( void );             //�Ǧ^�ثe���V�ʧ@���i��
        int                 FrameCount( int Sequence_no );  //�Ǧ^�ǤJ���ʧ@���h�ֱi��
        int                 FrameID( int act, int step );//�Ǧ^�ǤJact ���ʧ@-���Ǫ��ϧνs��

        void                Release( void );
        int                 Load( const char* path );
        void                Save( const char* path );
    };



    //-----------------------------------------------------------------------------
    // Name: class Body2d
    // Desc: store and control image data
    //------------------------------------------------------------------------------

    //typedef CPSmartPtr<CPIcon> spImage;

    class Resource2d : public Sprite2d
    {
		short           m_ImageCounter;              //�ʵe���Ƽ��񦸼ƪ��p�ƾ�

    protected:
        
        short           m_ReadImageCount;            //�ثe���J���Ϥ���
        short           m_InitReadImageCount;        //�]�w��l���J���Ϥ���

        //void            InitReadAnimCount( void );

    public:

        AnimTable       m_AnimTable;        //�ʧ@���v���s��
        Array<CPIcon*>  m_pIconList;        //store image

        Resource2d();
        ~Resource2d();


        virtual Perror  Load( const char* path );
        virtual void    Save( const char* path );


        virtual size_t  SequenceInsert( UINT seqno );
        virtual void    SequenceRemove( UINT seqno );
        virtual void    Do( int Act );                              //�����ʧ@

        int             UpdateAnim( int count = -1 );
        virtual CPIcon* Image( UINT i );                              //singled image
        virtual CPIcon* Image( void );                                 //singled image
        virtual CPIcon* Animation( int count = -1 );                   //Animation + Imageplaying image

        int             ImageListReAllot( UINT size );
        void            ImageListRelease( void );
    };


    /*
    //-----------------------------------------------------------------------------
    // Name: class CPG2Intellect
    // Desc: judge value of element
    //------------------------------------------------------------------------------
    class CPG2Intellect : public Body2d
    {
    protected:
        int             Judg_Dir                       ( CPVertex destpt );
    public:
        virtual void    Drag_To                        ( CPVertex new_norm );
        //virtual void    Scroll_To                      ( CPVertex new_norm );
        //�P�_
        virtual int     Proc                           ( CPVertex point, UINT uMsg, UINT wParam );
        virtual Pbool   isCollision                    ( CPVertex mpos );
        virtual Pbool   isCollisionImage               ( CPVertex mpos );
        Pbool           isCollision                    ( CPG2Intellect *srcobj );              //�I��
        //void            SpeedUp                        ( int speed );
        CPRect          Rect                           ( void );     //�@�νd��
        CPRect          Screen_Rect                    ( void );
        CPRect          Image_Rect                     ( void );     //�ϧνd��
        CPRect          Image_Screen_Rect              ( void );     //�ϧνd��
        void            Go_Route                       ( void );
        int             Find_Route                     ( CPVertex from, CPVertex to );
        //�ƥ�
        virtual void OnMouseNull   ( Pvoid ){};
        virtual void OnMouseOver   ( Pvoid ){};
        virtual void OnLMouseDown  ( Pvoid ){};
        virtual void OnRMouseDown  ( Pvoid ){};
        virtual void OnLMouseUp    ( Pvoid ){};
        virtual void OnRMouseUp    ( Pvoid ){};
        virtual void OnDrag        ( Pvoid ){};
        virtual void OnDragDrop    ( Pvoid ){};
        virtual void OnKeyDown     ( Pint key ){};
        virtual void OnKeyUp       ( Pint key ){};
    };
    */
};//namespace GE

#endif
