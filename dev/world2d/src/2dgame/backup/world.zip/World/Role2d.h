//Role.h header file of Role.cpp
//
//
//
//
//
//
//
//
//
//
//
//
//                                                         Pin
//
#ifndef ROLE2D_H
#define ROLE2D_H


#include <Element2d.h>
#include <DynArray.tl>
#include <ArrayMap.tl>


//Active status
const int _STATUS_WATTING   = 0;
const int _STATUS_PREPARE   = 1;
const int _STATUS_BEGIN_DO  = 2;
const int _STATUS_DOING     = 3;
const int _STATUS_DO_FINISH = 4;
const int _STATUS_BEGIN_MOVE= 5;
const int _STATUS_MOVING    = 6;
const int _STATUS_ARRIVE    = 7;


const int AS_DESTORYSELF    = -1;
const int AS_STANDBY        = 0;
const int AS_WALK           = 1;
const int AS_ATTACK         = 2;
const int AS_DEFENCE        = 3;
const int AS_MAGIC          = 4;
const int AS_HITBACK        = 5;
const int AS_MAGICATTACK    = 6;


namespace GE
{
    namespace World
    {
        class Terrain2d;

        /////////////////////////////////////////////////////////////////////////////////////////////
        // Role2d class ���⵲�c�]�w

        class Role2d : public Element2d
        {
            int                 m_MoveDistance;
            int                 m_AttackDistance;
            Terrain2d*          m_Inhabit;
            DynArray<Role2d*>   m_Children;

			void                JudgMotion( void );
            int                 JudgStatus( void );
			virtual int         JudgCollision( void ); 

        protected:

            PtrDlist<short>     m_WantToDo;   //�ǳƭn�����ʧ@  push to protected

            //�ʧ@
			void                ClearMotion( void );
            void                Relative_Sever_Target( void );
            void                Relative_Build_Target( Role2d* target );

            
            virtual void        OnResponse( void );
            
            void                Diffuse( int range );// search road can walk
            void                Search_Push_Result( std::vector<GVertex> path );
            void                Search_Push_Result( Array<int> path );

            int                 Bfs_Search( std::vector<GVertex>* path,
                                            GVertex from,
                                            GVertex to,
                                            int range );
            int                 Vector_Search( std::vector<GVertex>* path,
                                               GVertex from,
                                               GVertex to );

        public:

            DynArray<Role2d*>   m_Target;

            ArrayMap<int>       m_WeightMap;       //�[�v��
            Role2d*             m_obj;             //�ϥιD��


            Role2d();
            ~Role2d();

            void Reside( Terrain2d* world ) { m_Inhabit = world; }
            Terrain2d* GetWorld( void )     { return m_Inhabit;  }

            void        Do( int action, int times = 1 );       //set act

            void        To( GVertex MapPos );                  //set object 
            void        Go_To( GVertex MapPos );               //set object
			int         Load( const char* filename );

            void        Use( int PropertID = 0 );
            void        Use( Role2d* obj );
            virtual int Search_Path( GVertex from, GVertex to );

            Role2d*     Poperty( int ID = 0 ) { return m_obj; }
            Role2d*     Rolebreed( void );
            void        Update( CPIcon* Canvas = 0 );                //direction actS

        };
    };//World
};//GE



#endif