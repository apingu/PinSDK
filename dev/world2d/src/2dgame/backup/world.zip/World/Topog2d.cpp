//Topog.cpp map board compute class
//
//
//
//
//
//
//
//
//
//
//
//
//                                                         Pin
//

#include <math.h>
#include <Coord2d.h>
#include "Topog2d.h"


namespace GE
{
    namespace World
    {
		PM::Coord2d coord;

        inline GVertex Point_Chessboard_to_Map_Site( GVertex site )        //�ন�x�ή��I�y��
		{
			return site;
		}

        inline GVertex Point_Map_to_Chessboard_Site( GVertex site )        //�N�x�ή��I�y���ন�ù��I�y��
		{
			return site;
		}

        //�x��
        inline GVertex Rect_Chessboard_to_Map_Site( GVertex site )        //�ন�x�ή��I�y��
		{
			return coord.Rect_Chessboard_to_Map_Site( site );
		}

        inline GVertex Rect_Map_to_Chessboard_Site( GVertex site )        //�N�x�ή��I�y���ন�ù��I�y��
		{
			return coord.Rect_Map_to_Chessboard_Site( site );
		}

        //�٧�
        inline GVertex Rhomb_Chessboard_to_Map_Site( GVertex site )        //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
		{
			return coord.Rhomb_Chessboard_to_Map_Site( site );
		}

        inline GVertex Rhomb_Map_to_Chessboard_Site( GVertex site )         //�N�����I�ഫ���٧ή�y��                 parameters1:Grid width  parameters2:Grid height
		{
			return coord.Rhomb_Map_to_Chessboard_Site( site );
		}

        inline GVertex Rhomb_Chessboard_to_Map_Site_128_64( GVertex site )   //�ন128 64�٧ή��I�y��
		{
			return coord.Rhomb_Chessboard_to_Map_Site_128_64( site );
		}

        inline GVertex Rhomb_Map_to_Chessboard_Site_128_64( GVertex site )    //�N128 64�٧ή��I�y���ন�u���I�y��
		{
			return coord.Rhomb_Map_to_Chessboard_Site_128_64( site );
		}



        //=============================================================================
        //  Name : 
        //  Desc : constructor
        //=============================================================================
        Topog2d::Topog2d():Scene2d(),CPChessboard()
        {
			Release();
		    m_pMapToChessboardSite = Point_Chessboard_to_Map_Site;
		    m_pChessboardToMapSite = Point_Map_to_Chessboard_Site;
        }


        //=============================================================================
        //  Name : 
        //  Desc : distructor
        //=============================================================================
        Topog2d::~Topog2d()
        {
            Release();
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::Release( void )
        {
            CPChessboard::Destroy();
            //Pos()(0, 0);
            m_RhombGridWHScale = 1;
            m_Rhomb_Chessboard_Misregistration = 0;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::SetMapValue( int mapw, int maph,
				                   int w, int h, shape_t shape )
        {
            //CPChessboard::setValue(width, height, shape);
            m_Grid.width  = w;
            m_Grid.height = h;
            m_Grid.shape  = shape;

			coord.SetWidth( w );
			coord.SetHeight( h );

			//init funciton
			InitSiteConvertFunc( shape,
			                     //m_pScreenToChessboardSite,
		                         m_pMapToChessboardSite,
		                         //m_pChessboardToScreenSite,
		                         m_pChessboardToMapSite );

            if( m_Grid.shape == _P_RHOMBUS_ )
            {
                Rhomb_Grid_WHScale( w, h );
                Rhomb_Chessboard_Revise( w, h, maph );//�p��X�٧ή檺�a�ϰ����A�Ϩ�y�Ь�����
				//coord( width, height, m_Rhomb_Chessboard_Misregistration );
				coord.SetOffset( m_Rhomb_Chessboard_Misregistration );
            }


            return ;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::MarkArea( GVertex site, int Distance, int id )
        {
            /*
            for(int j = (site.y - Distance); j <= (site.y + Distance); j++)
                for(int i = (site.x - Distance); i <= (site.x + Distance); i++)
                    if( (abs(i - site.x) + abs(j - site.y)) <= Distance)
                        if((i >= 0) && (j >= 0))
                                //m_MapGrid(j, i).floor = id;        //�i������l
                             */
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::ClearArea( int id )
        {
            /*
            for(int i = 0 ; i < m_MapGrid.Row_Size() ; i++)
                    for(int j = 0 ; j < m_MapGrid.Col_Size() ; j++)
                      //m_MapGrid(i, j).floor = id;
                      */
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
		void Topog2d::InitSiteConvertFunc( shape_t gridtype,
		                                   SiteConvert map2chessboardSite,
		                                   SiteConvert chessboard2mapSite )

		{
            switch( gridtype )
            {

			case _P_POINT_:
			    m_pMapToChessboardSite = Point_Map_to_Chessboard_Site;
		        m_pChessboardToMapSite = Point_Chessboard_to_Map_Site;
				break;

            case _P_RECT_: 
				m_pMapToChessboardSite    = Rect_Map_to_Chessboard_Site;
		        m_pChessboardToMapSite    = Rect_Chessboard_to_Map_Site;
				break;

            case _P_RHOMBUS_:
				
				if( ( m_Grid.width == 128) && ( m_Grid.height == 64 ) )
				{
					m_pMapToChessboardSite = Rhomb_Map_to_Chessboard_Site_128_64;
                    m_pChessboardToMapSite = Rhomb_Chessboard_to_Map_Site_128_64;
				}
				else
				{
					m_pMapToChessboardSite = Rhomb_Map_to_Chessboard_Site;
					m_pChessboardToMapSite = Rhomb_Chessboard_to_Map_Site;
				}
 				//ScreenToChessboardSite = Rhomb_Screen_to_Chessboard_Site;
				//ChessboardToScreenSite = Rhomb_Chessboard_to_Screen_Site;
				
				break;
            }

		}


        //=============================================================================
        //  Name : 
        //  Desc : Site in screen
        //=============================================================================
        GVertex Topog2d::MapToScreenSite( GVertex Situs )
        {
            return Situs + GetScreenDatum();
        }


        //=============================================================================
        //  Name : 
        //  Desc : Site in map
        //=============================================================================
        GVertex Topog2d::ScreenToMapSite( GVertex Situs )
        {
            return Situs - GetScreenDatum();
        }

        //=============================================================================
        //  Name : 
        //  Desc : �p��a�ή檺���e���
        //=============================================================================
        float Topog2d::Rhomb_Grid_WHScale( int GridWidth, int GridHeight )
        {
            return m_RhombGridWHScale = ( float )
                                        ( ( float ) GridWidth /
                                          ( float ) GridHeight );
        }


        //=============================================================================
        //  Name : 
        //  Desc : ����a�ϥ��U���o�X������
        //=============================================================================
        int Topog2d::Rhomb_Chessboard_Revise( int GridWidth,
                                              int GridHeight,
                                              int MapHeight )
        {
            GVertex ScreenToMapSite;
            GVertex GridSite;
            m_Rhomb_Chessboard_Misregistration = 0;
            ScreenToMapSite.x = 0;           //����a�ϥ��U���o�X������
            ScreenToMapSite.y = MapHeight;
            GridSite = Rhomb_Map_to_Chessboard_Site( ScreenToMapSite );
            return m_Rhomb_Chessboard_Misregistration = abs( GridSite.x );
        }


        //=============================================================================
        //  Name : 
        //  Desc : �إߵ٧ή�y��2���}�C
        //=============================================================================
        bool Topog2d::Create_Chessboard( int MapWidth,
                                         int MapHeight,
                                         int GridWidth,
                                         int GridHeight,
                                         shape_t GridType )
        {
			SetMapValue( MapWidth, MapHeight, GridWidth, GridHeight, GridType );

            if( ( MapWidth == 0 ) ||
                ( MapHeight == 0 ) ||
                ( GridWidth == 0 ) ||
                ( GridHeight == 0 ) )
                return false;


            GVertex ScreenToMapSite;
            GVertex GridSite;
            //SetGridValue( GridWidth, GridHeight, GridType );
	
            //Rhomb_Grid_WHScale( m_Grid.width, m_Grid.height ); //Rhome��a�Ϊ����e��ҭ�
            if( m_Grid.shape == _P_RHOMBUS_ )   //�٧ή���
            {
                //Rhomb_Chessboard_Revise( m_Grid.width,
                //                         m_Grid.height,
                //                         MapHeight );

                ScreenToMapSite.x = MapWidth;    //����a�ϥk�W���o�X�x�}�e
                ScreenToMapSite.y = 0;
                GridSite = Rhomb_Map_to_Chessboard_Site( ScreenToMapSite );
                m_Cols = GridSite.x ;

                ScreenToMapSite.x = MapWidth;    //����a�ϥk�U���o�X�x�}��
                ScreenToMapSite.y = MapHeight;
                GridSite = Rhomb_Map_to_Chessboard_Site( ScreenToMapSite );
                m_Rows = GridSite.y ;
            }
            // �x��..........................
            else if( m_Grid.shape == _P_RECT_ )   //�٧ή���
            {
                m_Cols = ( int ) ceil( ( double ) ( MapWidth / GridWidth ) );
                m_Rows = ( int )
                         ceil( ( double ) ( MapHeight / GridHeight ) );
            }
            Board_Release_All();
            Board_Allot_All( m_Cols, m_Rows );
            InsertBoard( "Walkable.board", m_Cols, m_Rows );
            InsertBoard( "Event.board", m_Cols, m_Rows );

            return true;
        }

        bool Topog2d::Create_Chessboard( void )
        {
            return Create_Chessboard( ImageWidth(),
                                      ImageHeight(),
                                      m_Grid.width,
                                      m_Grid.height,
                                      m_Grid.shape );
        }

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::New_Chessboard( int MapWidth,
                                      int MapHeight,
                                      int GridWidth,
                                      int GridHeight,
                                      shape_t GridShape )
        {
            //Scene_Width()   = MapWidth;
            //Scene_Height()  = MapHeight;
            Create_Chessboard( ImageWidth(),
                               ImageHeight(),
                               GridWidth,
                               GridHeight,
                               GridShape );
        }


        //=============================================================================
        //  Name : 
        //  Desc : �Ǧ^��l�������I
        //=============================================================================
        GVertex Topog2d::GridCenterPoint( GVertex GridSite )
        {
            GVertex ScreenToMapSite= ChessboardToMapSite( GridSite );
            return  MapToScreenSite( ScreenToMapSite );
        }


		/*
		//=============================================================================
        //  Name : 
        //  Desc :�@�ഫ�x�ι���y��
        //=============================================================================
        inline LG::Point Topog2d::Rect_Chessboard_to_Map_Site( LG::Point GridSite, UINT w, UINT h )
        {
            LG::Point EntityPoint;

            EntityPoint.x = GridSite.x * w + ( w >> 1 );
            EntityPoint.y = GridSite.y * h + ( h >> 1 );

            return EntityPoint;
        }


        //=============================================================================
        //  Name : 
        //  Desc :�@�ഫ�x�Φۭq�y��
        //=============================================================================
        LG::Point Topog2d::Rect_Map_to_Chessboard_Site( LG::Point ScreenToMapSite, UINT w, UINT h )
        {
            LG::Point EntityPoint;

            EntityPoint.x = ScreenToMapSite.x / w ;
            EntityPoint.y = ScreenToMapSite.y / h;

            return EntityPoint;
        }


        //=============================================================================
        //  Name : 
        //  Desc :�@�N�����I�ഫ���٧ή�y�� 64 128
        //=============================================================================
        LG::Point Topog2d::Rhomb_Map_to_Chessboard_Site_128_64( LG::Point ScreenToMapSite, UINT w, UINT h )
        {
            LG::Point r;
            int x   = ScreenToMapSite.x;
            int y   = ScreenToMapSite.y;

            y <<= 1;

            r.x = ( x - y ) >> 7;   // (x - 2y) / 64 // (>> 7 ���e128)
            r.y = ( x + y ) >> 7;   // (x + 2y) / 64

            //�[�WX�����q �NX�b�_�I�q�t�Ȱ�����0
            r.x = r.x + m_Rhomb_Chessboard_Misregistration;
            return r;
        }

        //=============================================================================
        //  Name : 
        //  Desc :�@�N�����I�ഫ���٧ή�y��   ��l�e, ��l��
        //=============================================================================
        LG::Point Topog2d::Rhomb_Map_to_Chessboard_Site( LG::Point ScreenToMapSite, UINT w, UINT h )
		
        {
            rhomb( w, h, m_Rhomb_Chessboard_Misregistration );
            return rhomb.Coord( ScreenToMapSite.x, ScreenToMapSite.y );
        }


        //=============================================================================
        //  Name : 
        //  Desc : �N�٧ή�y���ഫ�������I(�ǥX���I�����I)64 128
        //=============================================================================
        LG::Point Topog2d::Rhomb_Chessboard_to_Map_Site_128_64( LG::Point GridSite, UINT w, UINT h )
        {
            LG::Point p;
            //��X�����q �NX�b�_�I�q0�����^�������
            int x   = GridSite.x - m_Rhomb_Chessboard_Misregistration;
            int y   = GridSite.y;

            p.x = ( x + y + 1 ) * ( 128 >> 1 );
            p.y = ( y - x ) * ( 64 >> 1 );

            return p;
        }


        //=============================================================================
        //  Name : 
        //  Desc :  �N�٧ή�y���ഫ�������I(�ǥX���I�����I) ��l�e, ��l��
        //=============================================================================
        LG::Point Topog2d::Rhomb_Chessboard_to_Map_Site( LG::Point GridSite, UINT w, UINT h )
        {
            rhomb( w, h, m_Rhomb_Chessboard_Misregistration );
            return rhomb.Seat( GridSite.x, GridSite.y );
        }
		*/


		/*
		
        GVertex Topog2d::Chessboard_to_Map_Site( GVertex GridSite )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return GridSite;
            case _P_RECT_:return Rect_Chessboard_to_Map_Site( GridSite,
                                                              m_Grid.width,
                                                              m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Chessboard_to_Map_Site( GridSite,
                                                                  m_Grid.width,
                                                                  m_Grid.height );
            }
            return GridSite;
        }


        GVertex Topog2d::Map_to_Chessboard_Site( GVertex Map_Situs )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return Map_Situs;
            case _P_RECT_:return Rect_Map_to_Chessboard_Site( Map_Situs,
                                                              m_Grid.width,
                                                              m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Map_to_Chessboard_Site( Map_Situs,
                                                                  m_Grid.width,
                                                                  m_Grid.height );
            }
            return Map_Situs;
        }

        GVertex Topog2d::Screen_to_Chessboard_Site( GVertex Screen_Situs )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return ScreenToMapSite( Screen_Situs );
            case _P_RECT_:return Rect_Screen_to_Chessboard_Site( Screen_Situs,
                                                                 m_Grid.width,
                                                                 m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Screen_to_Chessboard_Site( Screen_Situs,
                                                                     m_Grid.width,
                                                                     m_Grid.height );
            }
            return Screen_Situs;
        }


        GVertex Topog2d::Chessboard_to_Screen_Site( GVertex Grid )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return MapToScreenSite( Grid );
            case _P_RECT_:return Rect_Chessboard_to_Screen_Site( Grid,
                                                                 m_Grid.width,
                                                                 m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Chessboard_to_Screen_Site( Grid,
                                                                     m_Grid.width,
                                                                     m_Grid.height );
            }
            return Grid;
        }
		*/

    };//World
};//GE
