SetGrid(a, b, c);
Load_Backdrop(path, offset));
Create_Chessboard();