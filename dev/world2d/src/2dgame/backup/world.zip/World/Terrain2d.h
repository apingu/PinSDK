//Map.h header file of map.cpp
//
// Map Class
//
//
//
//             map data have inside data and outside data, 
//             inside data now have define grid middle point data, floor data
//             outside data read include grid structure data
//
//
//
//
//
//                                                         Pin
//

#ifndef TERRAIN2D_H
#define TERRAIN2D_H


#include "Topog2d.h"
#include "Role2d.h"
#include "Zone2d.h"


namespace GE
{
    namespace World
    {
        //enum  Shape{PM_Rect, PM_Rhomb};
        //class Role2d;
        ///////////////////////////////////////////////////////////////////////////////////
        //  Map class
        class Terrain2d : public Topog2d
        {
			Array<Role2d*>       m_PasteEntity;
			std::vector<Role2d*> m_AlphaEntity;

        protected:

            virtual void    Collide_Scroll( POINT point );

        public:

            GVertex         m_Mouse_Map_Site;
            GVertex         m_Mouse_Chessboard_Site;

            Terrain2d();
            ~Terrain2d();

            void            Release( void );
            void            ReleaseAllRole( void );

            //CPRect   MapRect         (void);
            virtual int     LoadBackGround( const char* path );
            virtual void    PasteBackGround( CPIcon* canvas );

            //file
            int             Load( Pcstr path );
            void            Save( Pcstr path );

            //get data
            //void          Drag_To           ( GVertex mpos );

            Role2d*         Role( int id );
            Role2d*         GetFocusRole( void );
            void            SetFocusRole( Role2d* role );
            void            JoinRole( Role2d* role );
            void            DepartRole( Role2d* role );

            //�ʧ@
            void            Update( LG::Point c );

            //�K��
			virtual void    RenderTerrain( CPIcon* canvas );
			virtual void    RenderEntity( CPIcon* canvas ); 

			//�Ƨ�
            virtual void    EntitySort( void );
			virtual void    RoleAlphaSort( void );
			virtual void    ElemAlphaSort( void );

            //
            virtual void    Query( GVertex point, Puint uMsg, Puint wParam );     //����

            //���|
            void            SetArea( char** array, int id );


	        virtual void    OnGetNeighbor( UINT gx, UINT gy,
    			                           std::vector< LG::Point >& neighbor );
			virtual void*   OnLoadCell   ( const char* filename,
			                               void** pData,
			                               void** pUserdata );
		    virtual void    OnReleaseCell( const char* filename,
			                               void* pData,
					                       void* pUserdata );


            /*
            bool     LoadMapSys  ( const char *MapPicPath,
                                   const char *MapInfoPath = NULL,
                                   int VedioMask  = 0,
                                   int GridWidth  = 128, int GridHeight = 64,
                                   BYTE GridShape = _p_rhombus_
                                 )
                    {
                        Load(MapPicPath, VedioMask);
                        if(!LoadData(MapInfoPath, GridWidth, GridHeight, GridShape))
                        {
                            Create_Chessboard(Scene_Width(), Scene_Height(), 
                                              GridWidth, GridHeight,
                                              GridShape);
                            return false;
                        }
                        return true;
                    }
                    */
        };
    };//World
};//GE

#endif
