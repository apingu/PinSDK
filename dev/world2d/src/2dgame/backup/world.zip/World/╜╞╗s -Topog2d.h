//Topog.h header file of Togog.cpp
//
//
//
//
//
//
//
//
//
//
//
//
//                                                         Pin
//

#ifndef TOPOG2D_H
#define TOPOG2D_H

#include <Chessboard.h>
#include <Scene2d.h>
#include <Element2d.h>


namespace GE
{
    namespace World
    {

        ///////////////////////////////////////////////////////////////////////////////////////////
        //  Topog class

        class Topog2d : public Scene2d , public CPChessboard
        {
		private:

            UINT    m_Rows;
            UINT    m_Cols;
            grid_t  m_Grid;
            int     m_Rhomb_Chessboard_Misregistration; //�٧ή�X����
            float   m_RhombGridWHScale;                 //�٧ή�e�����

		private:
			//typedef GVertex (*Screen2MapSite)       ( GVertex ScreenSite );
		    typedef GVertex (*Screen2ChessboardSite)( GVertex ScreenSite );
		    //typedef GVertex (*Map2ScreenSite)       ( GVertex ScreenSite );
		    typedef GVertex (*Map2SChessboardSite)  ( GVertex ScreenSite );
		    typedef GVertex (*Chessboard2ScreenSite)( GVertex ScreenSite );
		    typedef GVertex (*Chessboard2MapSite)   ( GVertex ScreenSite );


        protected:

            float   Rhomb_Grid_WHScale( int GridWidth, int GridHeight );                 //�a�ή���e���
            int     Rhomb_Chessboard_Revise( int GridWidth,
                                             int GridHeight,
                                             int MapHeight );  //

        public:


            Topog2d();
            ~Topog2d();

            void    Release( void );
            UINT    GetCols( void ) { return m_Cols; }
            UINT    GetRows( void ) { return m_Rows; }

            void    SetGridValue( int width, int height, short shape );


            //CPPOINT norm;        //�a�Ϫ���ڥ��W�I

            bool        Create_Chessboard( void );


            bool        Create_Chessboard( int MapWidth,
                                           int MapHeight,
                                           int GridWidth,
                                           int GridHeight,
                                           int GridType = _P_RECT_ );

            void        New_Chessboard( int MapWidth,
                                        int MapHeight,
                                        int GridWidth,
                                        int GridHeight,
                                        int GridShape = _P_RECT_ );



            void        MarkArea( GVertex site, int Distance, int id );                   //mark off area
            void        ClearArea( int id );                                              //clear area



			//Screen2MapSite          ScreenToMapSite;
		    Screen2ChessboardSite   ScreenToChessboardSite;
		    //Map2ScreenSite          MapToScreenSite;
		    Map2SChessboardSite     MapToChessboardSite;
		    Chessboard2ScreenSite   ChessboardToScreenSite;
		    Chessboard2MapSite      ChessboardToMapSite;



			//��l�p��
            GVertex    ScreenToMapSite( GVertex ScreenSite );                    //���ʬ۹�y��
            GVertex    MapToScreenSite( GVertex MapSite );                       //�۹�y��

            GVertex    Chessboard_to_Screen_Site( GVertex Grid );
            GVertex    Chessboard_to_Map_Site( GVertex GridSite );
            GVertex    Map_to_Chessboard_Site( GVertex MapSite );
            GVertex    Screen_to_Chessboard_Site( GVertex ScreenSite );



            //�x��
            GVertex    Rect_Chessboard_to_Map_Site( GVertex GridSitus,
                                                    int Width,
                                                    int Height );        //�ন�x�ή��I�y��
            GVertex    Rect_Map_to_Chessboard_Site( GVertex MapSite,
                                                    int Width,
                                                    int Height );         //�N�x�ή��I�y���ন�ù��I�y��
            GVertex    Rect_Screen_to_Chessboard_Site( GVertex ScreenSite,
                                                       int Width,
                                                       int Height )    //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            {
                return Rect_Map_to_Chessboard_Site( to_Map_Site( ScreenSite ),
                                                    Width,
                                                    Height );
            }
            GVertex Rect_Chessboard_to_Screen_Site( GVertex GridSitus,
                                                    int Width,
                                                    int Height )    //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            {
                return to_Screen_Site( Rect_Chessboard_to_Map_Site( GridSitus,
                                                                    Width,
                                                                    Height ) );
            }


            //�٧�
            virtual GVertex    Rhomb_Chessboard_to_Map_Site_128_64( GVertex GridSite/*Width = 128, Height = 64*/ );   //�ন128 64�٧ή��I�y��
            virtual GVertex    Rhomb_Map_to_Chessboard_Site_128_64( GVertex MapSite/*Width = 128, Height = 64*/ );    //�N128 64�٧ή��I�y���ন�u���I�y��

            virtual GVertex    Rhomb_Chessboard_to_Map_Site( GVertex GridSite,
                                                              int Width,
                                                              int Height );        //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            virtual GVertex    Rhomb_Map_to_Chessboard_Site( GVertex MapSite,
                                                              int Width,
                                                              int Height );         //�N�����I�ഫ���٧ή�y��                 parameters1:Grid width  parameters2:Grid height

            virtual GVertex Rhomb_Chessboard_to_Screen_Site( GVertex GridSite,
                                                              int Width,
                                                              int Height )    //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            {
                return to_Screen_Site( Rhomb_Chessboard_to_Map_Site( GridSite,
                                                                     Width,
                                                                     Height ) );
            }

            virtual GVertex Rhomb_Screen_to_Chessboard_Site( GVertex ScreenSite,
                                                              int Width,
                                                              int Height )    //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            {
                return Rhomb_Map_to_Chessboard_Site( to_Map_Site( ScreenSite ),
                                                     Width,
                                                     Height );
            }


            GVertex    GridCenterPoint( GVertex GridSite ); //computer grid center point
        };
    };//World
};//GE


#endif