//Topog.h header file of Togog.cpp
//
//
//
//
//
//
//
//
//
//
//
//
//                                                         Pin
//

#ifndef TOPOG2D_H
#define TOPOG2D_H

#include <Chessboard.h>
#include <Scene2d.h>
#include <Element2d.h>



namespace GE
{
    namespace World
    {

        ///////////////////////////////////////////////////////////////////////////////////////////
        //  Topog class

        class Topog2d : public Scene2d, public CPChessboard, public Element2d
        {
		private:

            UINT    m_Rows;
            UINT    m_Cols;
            grid_t  m_Grid;
            int     m_Rhomb_Chessboard_Misregistration; //�٧ή�X����
            float   m_RhombGridWHScale;                 //�٧ή�e�����


			typedef GVertex (*SiteConvert)( GVertex GridSite );
		    //SiteConvert  m_pScreenToChessboardSite;
		    SiteConvert  m_pMapToChessboardSite;
		    //SiteConvert  m_pChessboardToScreenSite;
		    SiteConvert  m_pChessboardToMapSite;
		//private:

        protected:

			virtual void InitSiteConvertFunc( shape_t gridtype,
		                                      SiteConvert map2chessboardSite,
		                                      SiteConvert chessboard2mapSite );


            float   Rhomb_Grid_WHScale( int GridWidth, int GridHeight );                 //�a�ή���e���
            int     Rhomb_Chessboard_Revise( int GridWidth,
                                             int GridHeight,
                                             int MapHeight );  //

        public:


            Topog2d();
            ~Topog2d();

            void    Release( void );
            UINT    GetCols( void ) { return m_Cols; }
            UINT    GetRows( void ) { return m_Rows; }
			UINT    GetGirdWidth( void ) { return m_Grid.width; }
			UINT    GetGirdHeight( void ) { return m_Grid.height; }
			UINT    GetGirdShape( void )  { return m_Grid.shape; }


            void    SetMapValue( int mapw, int maph,
				                 int w, int h, shape_t shape );

			


            //CPPOINT norm;        //�a�Ϫ���ڥ��W�I

            bool        Create_Chessboard( void );


            bool        Create_Chessboard( int MapWidth,
                                           int MapHeight,
                                           int GridWidth,
                                           int GridHeight,
                                           shape_t GridType = _P_RECT_ );

            void        New_Chessboard( int MapWidth,
                                        int MapHeight,
                                        int GridWidth,
                                        int GridHeight,
                                        shape_t GridShape = _P_RECT_ );


            void        MarkArea( GVertex site, int Distance, int id );                   //mark off area
            void        ClearArea( int id );                                              //clear area


			
			//��l�p��

            inline GVertex MapToChessboardSite( GVertex site )                         //�۹�y��
			{ return m_pMapToChessboardSite( site ); }       
            inline GVertex ChessboardToMapSite( GVertex site )                         //�۹�y��
			{ return m_pChessboardToMapSite( site ); }

            GVertex      ScreenToMapSite( GVertex ScreenSite );                    //���ʬ۹�y��
            GVertex      MapToScreenSite( GVertex MapSite );                       //�۹�y��

			inline GVertex    ScreenToChessboardSite( GVertex ScreenSite )     //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            { return MapToChessboardSite( ScreenToMapSite( ScreenSite ) ); }
            inline GVertex    ChessboardToScreenSite( GVertex GridSitus )      //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            { return MapToScreenSite( ChessboardToMapSite( GridSitus ) ); }

			GVertex    GridCenterPoint( GVertex GridSite ); //computer grid center point



		protected:
			

			/*
            //�x��
            virtual GVertex    Rect_Chessboard_to_Map_Site( GVertex GridSitus, UINT w, UINT h );        //�ন�x�ή��I�y��
            virtual GVertex    Rect_Map_to_Chessboard_Site( GVertex MapSite, UINT w, UINT h );        //�N�x�ή��I�y���ন�ù��I�y��

            //�٧�
            virtual GVertex    Rhomb_Chessboard_to_Map_Site( GVertex GridSite, UINT w, UINT h );        //�N�٧ή�y���ഫ�������I(�ǥX���I�����I) parameters1:Grid width  parameters2:Grid height
            virtual GVertex    Rhomb_Map_to_Chessboard_Site( GVertex MapSite, UINT w, UINT h );         //�N�����I�ഫ���٧ή�y��                 parameters1:Grid width  parameters2:Grid height

			//128 64�٧�
            virtual GVertex    Rhomb_Chessboard_to_Map_Site_128_64( GVertex GridSite, UINT w=128, UINT h=64 );   //�ন128 64�٧ή��I�y��
            virtual GVertex    Rhomb_Map_to_Chessboard_Site_128_64( GVertex MapSite, UINT w=128, UINT h=64 );    //�N128 64�٧ή��I�y���ন�u���I�y��
			*/   

        };
    };//World
};//GE


#endif