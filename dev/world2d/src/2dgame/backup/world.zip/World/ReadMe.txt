PCRole

using like this

VMCDX GDX;
CRole role1;

role1->Running();
GDX.AlphaStick( role1->Image(), fight1->Screen_Situs(), VMCanvas );

must get image as Image() now
