//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
#ifndef ZONE2D_H
#define ZONE2D_H

#include <Element2d.h>
#include <Chessboard.h>


namespace GE
{
    namespace World
    {
		class Zone2d : public Element2d, public CPChessboard
		{

		public:
			Zone2d();
			~Zone2d();



		};

	};
};


#endif //ZONE2D_H