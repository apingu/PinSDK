//Role.cpp game world role class
//
//
//
//
//
//
//
//
//
//
//
//                                                                  Pin
//

#include "Role2d.h"
#include "Terrain2d.h"
#include <stack>



namespace GE
{
    namespace World
    {
        const int _MAX_SERACH_RANGE = 30;

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        Role2d::Role2d()
        {
			memcpy( &CID, "ROLE", sizeof( CID ) );
            m_obj = 0;
            m_Inhabit = 0;
            m_MoveDistance = 3;
            m_AttackDistance = 1;
            m_Children.clear();
            m_WantToDo.clear();
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        Role2d::~Role2d()
        {
            m_obj = 0;    //�ϥιD��
            m_Inhabit = 0;
            m_Children.clear();
            m_Target.clear();
            m_WantToDo.clear();
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        Role2d* Role2d::Rolebreed( void )
        {
            Role2d* obj = new Role2d;
            /*
            memcpy(obj, this, sizeof(Role2d));
            (*m_ReferCount) ++;
            m_Target.clear();
            obj->m_Parent = this;
            obj->ID = (((*(this->m_ReferCount)) - 1) * 1000 + this->ID);
            */
            return obj;
        }

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::Relative_Build_Target( Role2d* target )
        {
            if( m_Target.find( target ) < 0 )  // if had build relative, we won't build againe
                m_Target.push_back( target );
            if( target->m_Target.find( this ) < 0 )  // if had build relative, we won't build againe
                target->m_Target.push_back( this );
            return;
        }


        //=============================================================================
        //  Name : Relative_Target_Sever()
        //  Desc : break relation with all Unit
        //=============================================================================
        void Role2d::Relative_Sever_Target( void )
        {
            for( Puint tarc = 0 ;tarc < m_Target.size() ;tarc++ )
                m_Target[ tarc ]->m_Target.clear();
            m_Target.clear();
            return;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::ClearMotion( void )
        {
            //clear all releation
            if( !m_Target.empty() )
            {
                UINT tars= 0;
                for( Puint tarc = 0 ;tarc < m_Target.size() ;tarc++ )
                {
                    if( ( m_Target[ tarc ]->GetNowDeedStatus() ==
                          _STATUS_WATTING ) ||
                        ( m_Target[ tarc ]->GetNowDeedStatus() ==
                          _STATUS_ARRIVE ) ||
                        ( m_Target[ tarc ]->GetNowDeedStatus() ==
                          _STATUS_DO_FINISH ) )
                    {
                        tars++;
                    }
                }
                if( tars == m_Target.size() ) //all role had finish their work then we can break all relative
                    Relative_Sever_Target();
            }

            Restore_Speed();
            m_Route.clear();
            m_WeightMap.clear();
            m_WantToDo.clear();

            if( m_AnimTable.GetNowSeqID() >= PRE_LOAD_SEQUENCE_COUNT )
                SequenceRemove( m_AnimTable.GetNowSeqID() );

            //Do( 0 );
			ChangeMotion( 0, Pos() );
			
            //m_Anim_Table.m_Behave_Act = 0;

            return;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::Use( Role2d* obj )
        {
            m_obj = obj->Rolebreed();
            m_obj->m_master = this;
        }

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::Use( int PropertID )
        {
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
		int Role2d::Load( const char* filename )
		{
			if( strcasestr( filename, ".elem" ) )
				memcpy( &CID, "ELEM", sizeof(CID) );
			return Element2d::Load( filename );
		}

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::Do( int action, int times )
        {
            for( int i = 0;i < times;i++ )
                m_WantToDo.push_back( action );
			m_WantToDo.GoBegin();

            //m_WantActTimes = times;
            //if(GetNowDeedStatus()() > 2)
            //  GetNowDeedStatus() = 1;
            return;
        }





        //=============================================================================
        //  Name : to_my_self()
        //  Desc : compute my self face to
        //=============================================================================
        GVertex to_my_self( int dir_count, int now_dir, GVertex now_situs )
        {
            GVertex face_pt;
            switch( dir_count )
            {
            case 4:
            {
                switch( now_dir )
                {
                case 0:face_pt( now_situs.x, now_situs.y + 1 );
                case 1:face_pt( now_situs.x - 1, now_situs.y );
                case 2:face_pt( now_situs.x, now_situs.y - 1 );
                case 3:face_pt( now_situs.x + 1, now_situs.y );
                }
            }
            default:
            {
                switch( now_dir )
                {
                case 0:face_pt( now_situs.x + 1, now_situs.y + 2 );
                case 1:face_pt( now_situs.x, now_situs.y + 1 );
                case 2:face_pt( now_situs.x - 1, now_situs.y + 1 );
                case 3:face_pt( now_situs.x, now_situs.y - 1 );
                case 4:face_pt( now_situs.x - 1, now_situs.y - 1 );
                case 5:face_pt( now_situs.x, now_situs.y - 1 );
                case 6:face_pt( now_situs.x + 1, now_situs.y - 1 );
                case 7:face_pt( now_situs.x + 1, now_situs.y );
                }
            }
            }
            return face_pt;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::To( GVertex Mappos )
        {
            // if face to self situs
            //m_Route.push_back( Pos() );
            //GVertex situs = m_Inhabit->to_Screen_Site( Mappos );
            if( Mappos == Pos() )
                Mappos = to_my_self( GetMaxAspect(), m_NowAspect, Pos() );

            m_Route.push_back( Mappos );//add goal to route

            //if this role put in world, judg if to situs have some one there
            if( ( m_Inhabit != NULL ) && ( !m_Inhabit->IsBoardEmpty() ) )
            {
                for( Puint i = 0;i < m_Inhabit->EntityCount();i++ )
                {
                    Role2d* target  = ( Role2d* ) ( m_Inhabit->Role( i ) );
                    if( target->IsCollision( Mappos ) )
                    {
                        if( target != this )//that guy not myself
                            Relative_Build_Target( target ); // i will do some thing to that guy
                        else//that guy is myself
                            Mappos = to_my_self( GetMaxAspect(),
                                                 m_NowAspect,
                                                 Pos() );
                        break;
                    }
                }


                /*
                    LG::Point GridPt = m_Inhabit->Screen_to_Chessboard_Site(situs); //to judge where we want to do
                    //if( m_WeightMap( GridPt.y, GridPt.x ) < 0 ) // is over our weight range
                    //  return;
                    if( ( GridPt.x > m_Inhabit->Get_Cols() ) || ( GridPt.y > m_Inhabit->Get_Rows() ) )// is over our weight range
                        return;
                    Role2d* target = (Role2d*)m_Inhabit->Who_on_that_block( GridPt );
                    if( target != 0 ) //have some guy on my goal
                    {
                        if( target != this )//that guy not myself
                            Relative_Build_Target( target ); // i will do some thing to that guy
                        else//that guy is myself
                            situs = to_my_self( GetMaxAspect(), m_Anim_Table.m_Now_Aspect, Pos());
                        //Role2d* elm = (Role2d*)m_Inhabit->m_MapUnit( GridPt.y, GridPt.x );
                        //To(elm);
                    }
                    
                    return;*/
            }
            //else
            //  m_Route.push_back( situs );


            m_Route.GoBegin();
            return;
        }





        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::Go_To( GVertex MapSitus )
        {
            // compute work path
            m_Route.clear();
            if( ( m_Inhabit != 0 ) && ( !m_Inhabit->IsBoardEmpty() ) )
            {
                //Diffuse( _MAX_SERACH_RANGE );
                //Search_Path( Pos(), m_Inhabit->to_Screen_Site( MapSitus ), _MAX_SERACH_RANGE );

                //Search_Path( Map_Situs(), MapSitus, 10 );
                Search_Path( Pos(), MapSitus );
            }else// role not have world go line path
                FindRoute( Pos(), MapSitus );
        }

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Role2d::Update( CPIcon* Canvas )
        {
            //m_Temp_Distance = m_Step;
            if( !Enable )
                return;

            switch( m_NowAct )
            {
            /*
            case AS_STANDBY:     STANDBY();     break ;
            case AS_WALK:        WALK();        break ;
            case AS_ATTACK:      ATTACK();      break ;
            case AS_DEFENCE:     DEFENCE();     break ;
            case AS_MAGIC:       MAGIC();       break ;
               case AS_HITBACK:     HITBACK();      break ;
            case AS_MAGICATTACK: MAGICATTACK(); break ;
            */
            case AS_DESTORYSELF:
            {
                {
                    Relative_Sever_Target();
                    if( m_Inhabit != 0 )
                        m_Inhabit->DepartRole( this );
                }
                return;
            }
            }

            OnResponse();
            JudgStatus();  //set m_Status value;
            JudgMotion();     //
            JudgCollision();

            return;
        }


        /*
        void Role2d::STANDBY(void)
        { 
            return ;//Image();
        }
        void Role2d::WALK(void)
        {
            return ;//Image();
        }
        void Role2d::ATTACK(void)
        {
            return ;//Image();
        }
        void Role2d::DEFENCE(void)
        {
            return ;//Image();
        }
        void Role2d::MAGIC(void)
        { 
            if(GetNowDeedStatus() == 2)
            {
                if(m_obj != 0)
                {
                    m_obj->Do(AS_ATTACK);
                    m_obj->Do(AS_DESTORYSELF);
                    m_obj->Pos()( m_Route.back().x, m_Route.back().y + 1 );
                    //m_obj->m_To = m_To;
                    m_Inhabit->Plant_Role(m_obj);
                 }
             }
             return ;//Image();
        }
        void Role2d::HITBACK(void)
        { 
            return ;//Image();
        }
        void Role2d::MAGICATTACK(void)
        {
            return ;//Image();
        }
        */


        //=============================================================================
        //
        // 0 __1___2_3_4 action end
        //         5_6_7 move   end
        // do one action must have action and direction
        // 0 wait for action and direction | 1 only have action or direction | 
        // 2 begin action | 3 actioning | 4 end act   |
        // 5 begin moving | 6 moving    | 7 end moving|
        // judgment GetNowDeedStatus()
        //=============================================================================
        int Role2d::JudgStatus( void )
        {
            //0
            if( ( m_Route.empty() ) && ( m_WantToDo.empty() ) )
                return m_NowDeedStatus = _STATUS_WATTING;

            switch( GetNowDeedStatus() )
            {
            case _STATUS_MOVING:
            {
                if( m_Route.empty() )
                    return m_NowDeedStatus = _STATUS_ARRIVE;
                return GetNowDeedStatus();
            }
            //
            case _STATUS_DOING:
            {
                if( GetNowFrameStatus() < -1 )  //end to action
                    return m_NowDeedStatus = _STATUS_DO_FINISH;
                return GetNowDeedStatus();
            }
            case _STATUS_BEGIN_DO:
            {
                //if( ( !m_Route.empty() ) && ( !m_WantToDo.empty() ) && ( m_Anim_Table.m_NowAct == m_WantToDo() ) )//  (GetNowDeedStatus() >= 2) && ( (m_WantToDo() == m_Anim_Table.m_NowAct) || (GetNowDeedStatus() == 3) ) )
                return m_NowDeedStatus = _STATUS_DOING;
            }
            case _STATUS_BEGIN_MOVE:
            {
                //6have dest, have action, situs between from and dest
                //if( ( !m_Route.empty() ) && ( !m_WantToDo.empty() ) && ( Pos() != m_Route.front() ) && ( Pos() != m_Route.back() ) )//  (GetNowDeedStatus() >= 2) && ( (m_WantToDo() == m_Anim_Table.m_NowAct) || (GetNowDeedStatus() == 3) ) )
                return m_NowDeedStatus = _STATUS_MOVING;
            }
            }

            //1
            if( ( ( m_Route.empty() ) + ( m_WantToDo.empty() ) ) == 1 )
                return m_NowDeedStatus = _STATUS_PREPARE;
            //2
            if( ( !m_Route.empty() ) &&
                ( !m_WantToDo.empty() ) &&
                ( m_Route.size() == 1 ) )//( m_Anim_Table.m_NowAct != m_WantToDo.front() ) )//&& ( (GetNowDeedStatus() < 2) || (GetNowDeedStatus() == 4) ) )//begin to action
                return m_NowDeedStatus = _STATUS_BEGIN_DO;
            //5 have dest, have action, situs in from
            if( ( !m_Route.empty() ) &&
                ( !m_WantToDo.empty() ) &&
                ( m_Route.size() != 1 ) )//( Pos() != m_Route.front() ) )//&& ( (GetNowDeedStatus() < 2) || (GetNowDeedStatus() == 4) ) )//begin to action
                return m_NowDeedStatus = _STATUS_BEGIN_MOVE;

            return -1;
        }


        //=============================================================================
        //  Name : JudgAct()
        //  Desc : judgment which value to be set in when status 
        //=============================================================================
        void Role2d::JudgMotion( void )
        {
            switch( GetNowDeedStatus() )
            {
            case _STATUS_ARRIVE://7
            {
                ClearMotion();
                return;
            }
            case _STATUS_DO_FINISH://4
            {
                m_WantToDo++;
                if( m_WantToDo.isBegin() ) //�����@���欰��A�ʧ@��C�بS���U�@�ӷǳƪ��欰
                {
                    ClearMotion();         //�M���Ҧ��ʧ@
                }
                //else                     //���^���A2�A�ǳƧ@�ʧ@��C�ت��U�@�Ӫ��ʧ@
                //{
                //m_Anim_Table.m_NowAct = -1;
                //}
                return;
            }
            case _STATUS_MOVING:
            {
                if( GetNowFrameStatus() < -1 )  //end to action
                {
                    m_WantToDo++;
					ChangeMotion( m_WantToDo(), m_Route() );
                    //Do( m_WantToDo() );
                }
                GoRoute();
                //Do( m_WantToDo() );
                return;
            }
            case _STATUS_BEGIN_DO://2
            {
                //m_NowAct = m_WantToDo();
				ChangeMotion( m_WantToDo(), m_Route() );
				//Faceto( m_Route() );
                //Do( m_WantToDo() );
                return;
            }
            case _STATUS_BEGIN_MOVE://5
            {
                //m_NowAct = m_WantToDo();
				ChangeMotion( m_WantToDo(), m_Route() );
                //Faceto( m_Route() );
                //Do( m_WantToDo() );
                //m_Route.pop_front();
                return;
            }
            }

            return ;//m_Anim_Table.m_NowAct;
        }

        //=============================================================================
        //
        //
        //=============================================================================
        void Role2d::OnResponse( void )
        {
            if( m_Target.empty() )
                return;

            int actsize = m_Target()->m_AnimTable.FrameCount();
            switch( m_Target()->m_NowAct )
            {
            case AS_ATTACK:
            {
                if( m_Target()->GetNowFrameStatus() ==
                    ( ( actsize / 3 ) * 2 ) )
                {
                    Do( AS_DEFENCE );
                    To( m_Target()->ScreenPos() );
                    //m_WantToDo.GoBegin();
                }
                if( m_Target()->GetNowFrameStatus() == actsize - 2 )
                {
                    Do( AS_HITBACK );
                    //To(m_Target()->ScreenPos() );
                    //m_WantToDo++;
                }
                break;
            }
            case AS_HITBACK:
            {
                if( m_Target()->GetNowFrameStatus() ==
                    ( ( actsize / 3 ) * 2 ) )
                {
                    Do( AS_DEFENCE );
                    To( m_Target()->ScreenPos() );
                    //m_Route.push_back(m_Target()->ScreenPos() );
                    //To(m_Target[0]->ScreenPos());
                    //m_WantToDo.GoBegin();
                }
                break;
            }
            case AS_MAGIC:
            {
                if( m_Target()->GetNowFrameStatus() == actsize / 5 * 4 )
                {
                    Do( AS_DEFENCE );
                    To( m_Target()->ScreenPos() );
                    //m_WantToDo.GoBegin();
                }
                break;
            }
            case AS_MAGICATTACK:
            {
                if( m_Target()->GetNowFrameStatus() == actsize / 5 * 4 )
                {
                    Do( AS_DEFENCE );
                    To( Pos() );
                    //m_WantToDo.GoBegin();
                }
                break;
            }
            }
        }


        //=============================================================================
        //  Name : JudgCollision()
        //  Desc : judgment which is collision
        //=============================================================================
        int Role2d::JudgCollision( void )
        {
            m_Collision = 0;
            if( ( m_Inhabit != 0 ) &&
                ( GetNowDeedStatus() == _STATUS_MOVING ) )
            {
                for( Puint i = 0;i < m_Inhabit->EntityCount();i++ )
                {
                    if( IsCollision( m_Inhabit->Role( i ) ) )
                    {
                        m_Collision++;
                    }
                }
            }
            return m_Collision;
        }



        //////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        //
        //=============================================================================
        //  Name : Search_Path()
        //  Desc : 
        //=============================================================================
        int Role2d::Search_Path( GVertex from, GVertex to )
        {
            std::vector<GVertex> path;
            Diffuse( _MAX_SERACH_RANGE );// search road can walk
            Bfs_Search( &path, from, to, _MAX_SERACH_RANGE );
            Search_Push_Result( path );

            return 1;//Bfs_Search( from, to, _MAX_SERACH_RANGE );
        }


        //=============================================================================
        //  Name : Search_Push_Result()
        //  Desc : 
        //=============================================================================
        void Role2d::Search_Push_Result( std::vector<GVertex> path )
        {
            if( m_Inhabit == 0 )
                return;

            for( Puint i = 1;i < path.size();i++ )
            {
                GVertex f_pos  = m_Inhabit->ChessboardToMapSite( path[ i - 1 ] );
                GVertex d_pos  = m_Inhabit->ChessboardToMapSite( path[ i ] );
                FindRoute( f_pos, d_pos );
                //m_Route.push_back(npos + _Map_norm);
            }
            m_Route.GoBegin();
        }


        //=============================================================================
        //  Name : Search_Push_Result()
        //  Desc : 
        //=============================================================================
        void Role2d::Search_Push_Result( Array<int> path )
        {
            GVertex p0, p1;
            for( Puint i = 1;i < path.size();i++ )
            {
                p0( HIWORD( path[ i - 1 ] ), LOWORD( path[ i - 1 ] ) );
                p1( HIWORD( path[ i ] ), LOWORD( path[ i ] ) );
                GVertex f_pos  = m_Inhabit->ChessboardToScreenSite( p0 );
                GVertex d_pos  = m_Inhabit->ChessboardToScreenSite( p1 );
                FindRoute( f_pos, d_pos );
                //m_Route.push_back(npos + _Map_norm);
            }
            m_Route.GoBegin();
        }


        void make_dir( int** d_x, int** d_y, int dir_c )
        {
            ( *d_x ) = new int[ dir_c ];
            ( *d_y ) = new int[ dir_c ];
            if( dir_c == 4 )
            {
                ( *d_x )[ 0 ] = 0; ( *d_x )[ 1 ] = 1; ( *d_x )[ 2 ] = 0; ( *d_x )[ 3 ] = -1;
                ( *d_y )[ 0 ] = -1; ( *d_y )[ 1 ] = 0; ( *d_y )[ 2 ] = 1; ( *d_y )[ 3 ] = 0;
            }
            if( dir_c == 8 )
            {
                ( *d_x )[ 0 ] = 0; ( *d_x )[ 1 ] = 1; ( *d_x )[ 2 ] = 1; ( *d_x )[ 3 ] = 1; ( *d_x )[ 4 ] = 0; ( *d_x )[ 5 ] = -1; ( *d_x )[ 6 ] = -1; ( *d_x )[ 7 ] = -1;
                ( *d_y )[ 0 ] = -1; ( *d_y )[ 1 ] = -1; ( *d_y )[ 2 ] = 0; ( *d_y )[ 3 ] = 1; ( *d_y )[ 4 ] = 1; ( *d_y )[ 5 ] = 1; ( *d_y )[ 6 ] = 0; ( *d_y )[ 7 ] = -1;
            }
        }



        void Role2d::Diffuse( int range )// search road can walk
        {
            GVertex pt = m_Inhabit->ScreenToChessboardSite( ScreenPos() );
            //int x = pt.x;
            //int y = pt.y;

			std::stack<POINT> pNodeStack[ 2 ];
            int* dx     = 0;
            int* dy     = 0;


            if( GetMaxAspect() == _4_Direction )
            {
                make_dir( &dx, &dy, 4 );
            }
            else if( GetMaxAspect() == _8_Direction )
            {
                make_dir( &dx, &dy, 8 );
            }
			else
			{
				return;
			}

            int depth;          // trace
            int toggle;         // toggle to use pNodeStack[0] or pNodeStack[1]

            assert( range > 0 );

            m_WeightMap.allot( m_Inhabit->GetCols(), m_Inhabit->GetRows() );
            m_WeightMap.set_element( -1 );

            m_WeightMap( pt.x, pt.y ) = range;

            // Push to stack0
            //pNodeStack[0][0] = MAKELONG(x, y);      // search will from this node
            //nStackHead[0] = 1;                      // and push new node to this stack
            POINT fpt   ={pt.x, pt.y};
            pNodeStack[ 0 ].push( pt );

            // Clear stack1
            //nStackHead[1] = 0;                      


            depth = range - 1;
            toggle = 0;

            do
            {
                //while (nStackHead[toggle])
                while( !pNodeStack[ toggle ].empty() )
                {
                    // Pop from stack
                    //DWORD pos = pNodeStack[toggle][nStackHead[toggle] - 1];
                    LG::Point pos   = pNodeStack[ toggle ].top();
                    pNodeStack[ toggle ].pop();

                    //y = HIWORD(pos);
                    //x = LOWORD(pos);

                    //nStackHead[toggle]--;

                    // Search all his branchs
                    for( int i = 0;i < GetMaxAspect();i++ )
                    {
                        LG::Point n;
                        n.x = pos.x + dx[ i ];
                        n.y = pos.y + dy[ i ];

                        if( m_Inhabit->GetData( GATEWAY_BOARD, n.x, n.y ) ==
                            0 )
                            continue;                   // block cell

                        if( m_WeightMap( n.x, n.y ) >= 0 )
                            continue;                   // already searched

                        m_WeightMap( n.x, n.y ) = depth;      // mark searched w/ depth

                        // Push to stack
                        //pNodeStack[1 - toggle][nStackHead[1 - toggle]] = MAKELONG(nx, ny);
                        //nStackHead[1 - toggle]++;
                        pNodeStack[ 1 - toggle ].push( n );

                        //assert(nStackHead[1 - toggle] < MAX_STACK_LEN);
                    }
                }   

                toggle = 1 - toggle;
                depth--;
            }while( depth >= 0 );

            if( dx != 0 )
                delete [] dx;
            if( dy != 0 )
                delete [] dy;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        //
        int Role2d::Bfs_Search( std::vector<GVertex>* path,
                                GVertex from,
                                GVertex to,
                                int maxStep )
        {
            //return -1;

            //std::vector<GVertex> path;
            int ( *getdir ) ( LG::Point pt1, LG::Point pt2 ); 

            GVertex g_from ( m_Inhabit->MapToChessboardSite( from ) ); 
            GVertex g_to   ( m_Inhabit->MapToChessboardSite( to ) );

            int depth       = m_WeightMap( g_to.x, g_to.y );

            if( depth == -1 )
                return 0;


            int step    = m_WeightMap( g_from.x, g_from.y ) - depth;
            if( step <= 0 )
                return 0;

            assert( step > 0 && step <= maxStep );

            path->insert( path->begin(), g_to );
            int tail    = step - 1;

            int* dx     = 0;
            int* dy     = 0;

            if( GetMaxAspect() == _4_Direction )
            {
                make_dir( &dx, &dy, 4 );
                getdir = dir4_by_point;
            }
            if( GetMaxAspect() == _8_Direction )
            {
                make_dir( &dx, &dy, 8 );
                getdir = dir8_by_point;
            }

            int begin_dir   = -1;
            GVertex npos;   
            while( depth != m_WeightMap( g_from.x, g_from.y ) )
            {
                begin_dir = getdir( g_to, g_from );

                for( int i = 0;i < GetMaxAspect();i++ )
                {
                    if( begin_dir >= GetMaxAspect() )
                        begin_dir = 0;

                    npos( g_to.x + dx[ begin_dir ], g_to.y + dy[ begin_dir ] );

                    if( m_WeightMap( npos.x, npos.y ) > depth )
                    {
                        // Add this node to array
                        //path.push_front(npos);
                        path->insert( path->begin(), npos );
                        g_to.x = npos.x;
                        g_to.y = npos.y;
                        break;
                    }
                    begin_dir++;
                }     

                depth++;
            }

            //path.GoBegin();

            if( dx != 0 )
                delete [] dx;
            if( dy != 0 )
                delete [] dy;

            return step;
        }


        int Role2d::Vector_Search( std::vector<GVertex>* path,
                                   GVertex from,
                                   GVertex to )
        {
            int modelslope  = ( int ) SLOPE( from, to );
            GVertex g_from ( m_Inhabit->MapToChessboardSite( from ) ); 
            GVertex g_to   ( m_Inhabit->MapToChessboardSite( to ) );

            int* dx         = 0;
            int* dy         = 0;

            if( GetMaxAspect() == _4_Direction )
            {
                make_dir( &dx, &dy, 4 );
            }
            if( GetMaxAspect() == _8_Direction )
            {
                make_dir( &dx, &dy, 8 );
            }

            int depth   = m_WeightMap( g_to.x, g_to.y );

            if( depth == -1 )
                return 0;


            int step    = m_WeightMap( g_from.x, g_from.y ) - depth;
            if( step <= 0 )
                return 0;

            //assert(step > 0 && step <= maxStep);

            path->insert( path->begin(), g_to );
            int tail    = step - 1;

            GVertex npos;   
            while( depth != m_WeightMap( g_from.x, g_from.y ) )
            {
                for( int i = 0;i < GetMaxAspect();i++ )
                {
                    npos( g_to.x + dx[ i ], g_to.y + dy[ i ] );

                    if( m_WeightMap( npos.x, npos.y ) > depth )
                    {
                        // Add this node to array
                        //path.push_front(npos);
                        path->insert( path->begin(), npos );
                        g_to.x = npos.x;
                        g_to.y = npos.y;
                        break;
                    }
                }     

                depth++;
            }

            //path.GoBegin();

            if( dx != 0 )
                delete [] dx;
            if( dy != 0 )
                delete [] dy;

            return step;
        }
    };//World
};//GE

