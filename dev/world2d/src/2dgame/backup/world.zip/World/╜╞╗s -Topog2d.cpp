//Topog.cpp map board compute class
//
//
//
//
//
//
//
//
//
//
//
//
//                                                         Pin
//

#include <math.h>
#include <Rhomb2d.h>
#include "Topog2d.h"


namespace GE
{
    namespace World
    {
		PM::Rhomb rhomb;

        //=============================================================================
        //  Name : 
        //  Desc : constructor
        //=============================================================================
        Topog2d::Topog2d():Scene2d(),CPChessboard()
        {
            Release();
        }


        //=============================================================================
        //  Name : 
        //  Desc : distructor
        //=============================================================================
        Topog2d::~Topog2d()
        {
            Release();
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::Release( void )
        {
            CPChessboard::Destroy();
            //Pos()(0, 0);
            m_RhombGridWHScale = 1;
            m_Rhomb_Chessboard_Misregistration = 0;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::SetGridValue( int width, int height, short shape )
        {
            //CPChessboard::setValue(width, height, shape);
            m_Grid.width = width;
            m_Grid.height = height;
            m_Grid.shape = shape;

            if( m_Grid.shape == _P_RHOMBUS_ )
            {
                Rhomb_Grid_WHScale( width, height );
                Rhomb_Chessboard_Revise( width, height, Scene_Height() );//�p��X�٧ή檺�a�ϰ����A�Ϩ�y�Ь�����
            }

            return ;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::MarkArea( GVertex site, int Distance, int id )
        {
            /*
            for(int j = (site.y - Distance); j <= (site.y + Distance); j++)
                for(int i = (site.x - Distance); i <= (site.x + Distance); i++)
                    if( (abs(i - site.x) + abs(j - site.y)) <= Distance)
                        if((i >= 0) && (j >= 0))
                                //m_MapGrid(j, i).floor = id;        //�i������l
                             */
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::ClearArea( int id )
        {
            /*
            for(int i = 0 ; i < m_MapGrid.Row_Size() ; i++)
                    for(int j = 0 ; j < m_MapGrid.Col_Size() ; j++)
                      //m_MapGrid(i, j).floor = id;
                      */
        }

        //=============================================================================
        //  Name : 
        //  Desc : Site in screen
        //=============================================================================
        GVertex Topog2d::MapToScreenSite( GVertex Situs )
        {
            return Situs + Pos();
        }


        //=============================================================================
        //  Name : 
        //  Desc : Site in map
        //=============================================================================
        GVertex Topog2d::ScreenToMapSite( GVertex Situs )
        {
            return Situs - Pos();
        }


        //=============================================================================
        //  Name : 
        //  Desc :�@�ഫ�x�ι���y��
        //=============================================================================
        GVertex Topog2d::Rect_Chessboard_to_Map_Site( GVertex GridSite,
                                                         int GridWidth,
                                                         int GridHeight )
        {
            GVertex EntityPoint;

            EntityPoint.x = GridSite.x * GridWidth + ( GridWidth >> 1 );
            EntityPoint.y = GridSite.y * GridHeight + ( GridHeight >> 1 );

            return EntityPoint;
        }


        //=============================================================================
        //  Name : 
        //  Desc :�@�ഫ�x�Φۭq�y��
        //=============================================================================
        GVertex Topog2d::Rect_Map_to_Chessboard_Site( GVertex to_Map_Site,
                                                         int GridWidth,
                                                         int GridHeight )
        {
            GVertex EntityPoint;

            EntityPoint.x = to_Map_Site.x / GridWidth ;
            EntityPoint.y = to_Map_Site.y / GridHeight;

            return EntityPoint;
        }


        //=============================================================================
        //  Name : 
        //  Desc :�@�N�����I�ഫ���٧ή�y�� 64 128
        //=============================================================================
        GVertex Topog2d::Rhomb_Map_to_Chessboard_Site_128_64( GVertex to_Map_Site )
        {
            GVertex r;
            int x   = to_Map_Site.x;
            int y   = to_Map_Site.y;

            y <<= 1;

            r.x = ( x - y ) >> 7;   // (x - 2y) / 64 // (>> 7 ���e128)
            r.y = ( x + y ) >> 7;   // (x + 2y) / 64

            //�[�WX�����q �NX�b�_�I�q�t�Ȱ�����0
            r.x = r.x + m_Rhomb_Chessboard_Misregistration;
            return r;
        }

        GVertex Topog2d::Rhomb_Map_to_Chessboard_Site( GVertex to_Map_Site,
                                                          int Width,
                                                          int Height )           //�N�����I�ഫ���٧ή�y��   ��l�e, ��l��
        {
            rhomb( Width, Height, m_Rhomb_Chessboard_Misregistration );
            return rhomb.Coord( to_Map_Site.x, to_Map_Site.y );
        }


        //=============================================================================
        //  Name : 
        //  Desc : �N�٧ή�y���ഫ�������I(�ǥX���I�����I)64 128
        //=============================================================================
        GVertex Topog2d::Rhomb_Chessboard_to_Map_Site_128_64( GVertex GridSite )
        {
            GVertex p;
            //��X�����q �NX�b�_�I�q0�����^�������
            int x   = GridSite.x - m_Rhomb_Chessboard_Misregistration;
            int y   = GridSite.y;

            p.x = ( x + y + 1 ) * ( 128 >> 1 );
            p.y = ( y - x ) * ( 64 >> 1 );

            return p;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        GVertex Topog2d::Rhomb_Chessboard_to_Map_Site( GVertex GridSite,
                                                          int Width,
                                                          int Height )          // �N�٧ή�y���ഫ�������I(�ǥX���I�����I) ��l�e, ��l��
        {
            rhomb( Width, Height, m_Rhomb_Chessboard_Misregistration );
            return rhomb.Seat( GridSite.x, GridSite.y );
        }


        GVertex Topog2d::Chessboard_to_Map_Site( GVertex GridSite )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return GridSite;
            case _P_RECT_:return Rect_Chessboard_to_Map_Site( GridSite,
                                                              m_Grid.width,
                                                              m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Chessboard_to_Map_Site( GridSite,
                                                                  m_Grid.width,
                                                                  m_Grid.height );
            }
            return GridSite;
        }


        GVertex Topog2d::Map_to_Chessboard_Site( GVertex Map_Situs )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return Map_Situs;
            case _P_RECT_:return Rect_Map_to_Chessboard_Site( Map_Situs,
                                                              m_Grid.width,
                                                              m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Map_to_Chessboard_Site( Map_Situs,
                                                                  m_Grid.width,
                                                                  m_Grid.height );
            }
            return Map_Situs;
        }

        GVertex Topog2d::Screen_to_Chessboard_Site( GVertex Screen_Situs )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return to_Map_Site( Screen_Situs );
            case _P_RECT_:return Rect_Screen_to_Chessboard_Site( Screen_Situs,
                                                                 m_Grid.width,
                                                                 m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Screen_to_Chessboard_Site( Screen_Situs,
                                                                     m_Grid.width,
                                                                     m_Grid.height );
            }
            return Screen_Situs;
        }


        GVertex Topog2d::Chessboard_to_Screen_Site( GVertex Grid )
        {
            switch( m_Grid.shape )
            {
            case _P_POINT_:return to_Screen_Site( Grid );
            case _P_RECT_:return Rect_Chessboard_to_Screen_Site( Grid,
                                                                 m_Grid.width,
                                                                 m_Grid.height );
            case _P_RHOMBUS_:return Rhomb_Chessboard_to_Screen_Site( Grid,
                                                                     m_Grid.width,
                                                                     m_Grid.height );
            }
            return Grid;
        }


        //=============================================================================
        //  Name : 
        //  Desc : �p��a�ή檺���e���
        //=============================================================================
        float Topog2d::Rhomb_Grid_WHScale( int GridWidth, int GridHeight )
        {
            return m_RhombGridWHScale = ( float )
                                        ( ( float ) GridWidth /
                                          ( float ) GridHeight );
        }


        //=============================================================================
        //  Name : 
        //  Desc : ����a�ϥ��U���o�X������
        //=============================================================================
        int Topog2d::Rhomb_Chessboard_Revise( int GridWidth,
                                                int GridHeight,
                                                int MapHeight )
        {
            GVertex to_Map_Site;
            GVertex GridSite;
            m_Rhomb_Chessboard_Misregistration = 0;
            to_Map_Site.x = 0;           //����a�ϥ��U���o�X������
            to_Map_Site.y = MapHeight;
            GridSite = Topog2d::Rhomb_Map_to_Chessboard_Site( to_Map_Site,
                                                                GridWidth,
                                                                GridHeight );
            return m_Rhomb_Chessboard_Misregistration = abs( GridSite.x );
        }


        //=============================================================================
        //  Name : 
        //  Desc : �إߵ٧ή�y��2���}�C
        //=============================================================================
        bool Topog2d::Create_Chessboard( int MapWidth,
                                           int MapHeight,
                                           int GridWidth,
                                           int GridHeight,
                                           int GridType )
        {
            if( ( MapWidth == 0 ) ||
                ( MapHeight == 0 ) ||
                ( GridWidth == 0 ) ||
                ( GridHeight == 0 ) )
                return false;

            GVertex to_Map_Site;
            GVertex GridSite;

            SetGridValue( GridWidth, GridHeight, GridType );
            Rhomb_Grid_WHScale( m_Grid.width, m_Grid.height ); //Rhome��a�Ϊ����e��ҭ�
            if( GridType == _P_RHOMBUS_ )   //�٧ή���
            {
                Rhomb_Chessboard_Revise( m_Grid.width,
                                         m_Grid.height,
                                         MapHeight );

                to_Map_Site.x = MapWidth;    //����a�ϥk�W���o�X�x�}�e
                to_Map_Site.y = 0;
                GridSite = Topog2d::Rhomb_Map_to_Chessboard_Site( to_Map_Site,
                                                                    GridWidth,
                                                                    GridHeight );
                m_Cols = GridSite.x ;

                to_Map_Site.x = MapWidth;    //����a�ϥk�U���o�X�x�}��
                to_Map_Site.y = MapHeight;
                GridSite = Topog2d::Rhomb_Map_to_Chessboard_Site( to_Map_Site,
                                                                    GridWidth,
                                                                    GridHeight );
                m_Rows = GridSite.y ;
            }
            // �x��..........................
            else if( GridType == _P_RECT_ )   //�٧ή���
            {
                m_Cols = ( int ) ceil( ( double ) ( MapWidth / GridWidth ) );
                m_Rows = ( int )
                         ceil( ( double ) ( MapHeight / GridHeight ) );
            }
            Board_Release_All();
            Board_Allot_All( m_Cols, m_Rows );
            InsertBoard( "Walkable.board", m_Cols, m_Rows );
            InsertBoard( "Event.board", m_Cols, m_Rows );

            return true;
        }

        bool Topog2d::Create_Chessboard( void )
        {
            return Create_Chessboard( Scene_Width(),
                                      Scene_Height(),
                                      m_Grid.width,
                                      m_Grid.height,
                                      m_Grid.shape );
        }

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Topog2d::New_Chessboard( int MapWidth,
                                        int MapHeight,
                                        int GridWidth,
                                        int GridHeight,
                                        int GridShape )
        {
            //Scene_Width()   = MapWidth;
            //Scene_Height()  = MapHeight;
            Create_Chessboard( Scene_Width(),
                               Scene_Height(),
                               GridWidth,
                               GridHeight,
                               GridShape );
        }


        //=============================================================================
        //  Name : 
        //  Desc : �Ǧ^��l�������I
        //=============================================================================
        GVertex Topog2d::GridCenterPoint( GVertex GridSite )
        {
            GVertex to_Map_Site= Chessboard_to_Map_Site( GridSite );
            return  to_Screen_Site( to_Map_Site );
        }
    };//World
};//GE
