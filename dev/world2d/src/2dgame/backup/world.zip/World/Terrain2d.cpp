//Map.cpp game map class
//
//                map have three king site
//                             screen site
//                             map    site
//                             grid   site
//
//
//
//
//
//
//
//                                                         Pin
//

#include "Terrain2d.h"
#include <aIntersect.h>
#include <PGSPFile.h>



namespace GE
{
    namespace World
    {
#define _G2ROLE( e )     ( (Role2d*)e )

        int compare( const void* elem1, const void* elem2 );

        ////////////////////////////////////////////////////////////////////////////////////////////
        //  Terrain2d class
        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        Terrain2d::Terrain2d():Topog2d()
        {
            //m_ScrollSpeed = 0;
            ID = -2;  //set background id is -2
            GID = -2;  //set background gid is -2
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        Terrain2d::~Terrain2d()
        {
            //m_ScrollSpeed = 0;
            Release();
            ReleaseAllRole();
        }

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Terrain2d::Release( void )
        {
            Element2d::Release();
            Topog2d::Release();
            //m_ScrollSpeed = 0;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Terrain2d::ReleaseAllRole( void )
        {
			SetFocusRole( NULL );
            for( UINT i = 0;i < EntityCount();i++ )
            {
                delete Role( i );
            }
            EntityClear();
			m_PasteEntity.clear();
			m_AlphaEntity.clear();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////
        //          Ū�J�a�ϸ��
        ////////////////////////////////////////////////////////////////////////////////////////////
        /*
        bool Terrain2d::LoadData(const char *MapInfoPath,
                            int GridWidth, int GridHeight,
                            BYTE GridShape
                            )
        {
            if(MapInfoPath == NULL)
                return false;
            FILE *Data;
            if((Data=fopen(MapInfoPath,"rb")) == NULL)//�}�ɦp�G-1�h���ѡA�Ǧ^-1
            {
                char msg[300];
                sprintf(msg,"Load map information file %s failure !!!", MapInfoPath);
                MessageBox(NULL,msg, "Load Failed", MB_OK);
                return false;
            }
            SetGridValue(GridWidth, GridHeight, GridShape);
            char Title[4];
            fread(Title, sizeof(Title), 1, Data);
            if((Title[0] != 'P') && (Title[1] != 'M') && (Title[2] != 'I'))
            {
                MessageBox(NULL,"����ɮ׮榡���~!!!","Ū�ɿ��~", MB_OK);
                return false;
            }
            fread(&m_Chessboard_Cols, sizeof(m_Chessboard_Cols), 1, Data);
            fread(&m_Chessboard_Rows, sizeof(m_Chessboard_Rows), 1, Data);
            //�ʺA�إߦs��C�Ӧa�Ϫ��G���}�C=====================================
            /*
            m_walkable.Allot(m_Chessboard_Cols, m_Chessboard_Rows);  //�i�����i��
            m_MapObject.Allot(m_Chessboard_Cols, m_Chessboard_Rows); //����
            m_MapObject.SetValue(0);
            m_event.Allot(m_Chessboard_Cols, m_Chessboard_Rows);
            */
        //end �ʺA�إߦs��C�Ӧa�Ϫ��G���}�C=================================

        //Ū�Jwalkable
        /*
        for(int i = 0 ; i < m_Chessboard_Rows; i++)
               for(int j = 0; j < m_Chessboard_Cols; j++)
                   fread(&m_walkable(i, j),sizeof(bool),1,Data);
        DWORD ArrayCols;
           DWORD ArrayRows;
        //read event
        fread(&ArrayCols, sizeof(ArrayCols), 1, Data);
        fread(&ArrayRows, sizeof(ArrayRows), 1, Data);
        if((ArrayCols != m_Chessboard_Cols) && (ArrayRows != m_Chessboard_Rows))
        {
            fclose(Data);
            return false;
        }
        for(i = 0 ; i < m_Chessboard_Rows; i++)
               for(int j = 0; j < m_Chessboard_Cols; j++)
                   fread(&m_event(i, j),sizeof(short),1,Data);
        fread(&ArrayCols, sizeof(ArrayCols), 1, Data);
        fread(&ArrayRows, sizeof(ArrayRows), 1, Data);
        m_MapGrid.Allot(ArrayCols, ArrayRows);
        for(i = 0 ; i < ArrayRows; i++)
               for(int j = 0; j < ArrayCols; j++)
        //            fread(&m_MapGrid(i, j),sizeof(_Gridtype),1,Data);
           fclose(Data);
        return true;
        }
        */
        //==========================================================================================
        //  Name : SetFocusRole()
        //  Desc : get a role form this world
        //==========================================================================================
        void Terrain2d::SetFocusRole( Role2d* role )
        {
			if( role != NULL )
			    GameSpace::SetFocusEntity( role->m_Descriptor );
			else
				GameSpace::SetFocusEntity( NULL );
            return;// _G2ROLE( SetFocusEntity( frole ) );
        }

        //==========================================================================================
        //  Name :
        //  Desc :
        //==========================================================================================
        Role2d* Terrain2d::GetFocusRole( void )
        {
            return _G2ROLE( GetFocusEntity() );
        }


        //==========================================================================================
        //  Name : GetRole()
        //  Desc : get a role form this world
        //==========================================================================================
        Role2d* Terrain2d::Role( int id )
        {
            return _G2ROLE( Entity( id ) );
        }

        //==========================================================================================
        //  Name : RolePlant()
        //  Desc : Plant a role into this world
        //==========================================================================================
        void Terrain2d::JoinRole( Role2d* role )
        {
            if( role == 0 )
                return;
            role->Reside( this );
			Scene2d::InsertEntity( role );
            return;
        }


        //==========================================================================================
        //  Name : RoleUproot()
        //  Desc : Eradicate a role form this world
        //==========================================================================================
        void Terrain2d::DepartRole( Role2d* role )
        {
            if( GetFocusEntity() == role )
                SetFocusEntity( NULL );

            role->Reside( NULL );
			Scene2d::RemoveEntity( role );
            return;
        }


        //==========================================================================================
        //  Name : Object_Moving()
        //  Desc : all role idle
        //==========================================================================================
        void Terrain2d::Update( LG::Point c )
        {
		    UpdateCenter( c );

            for( UINT j = 0;j < EntityCount();j++ )
            {
                //GVertex BeforeSitus = MapToChessboardSite( m_Temp_Object[j]->Map_Situs() );
                //�N�ثe�Ҧb��m��]��0
                //m_MapObject( BeforeSitus.x, BeforeSitus.y ) = 0;
                //Set_Board_Grid( GATEWAY_BOARD, BeforeSitus.x, BeforeSitus.y, true );
                ( ( Role2d * ) Entity( j ) )->Update( 0 );//next step
                //�N�ثe�Ҧb��m
                /*              
                        CPRect  MapRange = m_Temp_Object[j]->Map_Rect();
                            
                        GVertex NowSitus = MapToChessboardSite( m_Temp_Object[j]->Map_Situs() );
                        GVertex Range0 = MapToChessboardSite( MapRange.p_l_t() );
                        GVertex Range1 = MapToChessboardSite( MapRange.p_r_t() );
                        GVertex Range2 = MapToChessboardSite( MapRange.p_r_b() );
                        GVertex Range3 = MapToChessboardSite( MapRange.p_l_b() );
                                                          
                        //�N�ثe�Ҧb��m��]�J
                        for( int h = Range0.y; h <= Range2.y; h++ )
                        {
                            for( int w = Range3.x; w <= Range1.x; w++ )
                            {
                                 if( m_Temp_Object[j]->Is_In_Area( Chessboard_to_Screen_Site( GVertex( w, h ) ) ) )
                                     m_MapObject( w, h ) = m_Temp_Object[j];
                                     
                            }
                        }
                        //m_MapObject( NowSitus.x, NowSitus.y ) = m_Temp_Object[j];
                                            
                            
                        //�N����]�����i��
                        //Set_Board_Grid( GATEWAY_BOARD, NowSitus.x, NowSitus.y, false );
                        */
            }
        }


        //=============================================================================
        //  Name : compare()
        //  Desc : compare for map order
        //=============================================================================
        int compare2d( const void* elem1, const void* elem2 )
        {
            if( ( ( *( Element2d * * ) elem1 )->Pos().y ) >
                ( ( *( Element2d * * ) elem2 )->Pos().y ) )
                return 1;
            else if( ( ( *( Element2d * * ) elem1 )->Pos().y ) ==
                     ( ( *( Element2d * * ) elem2 )->Pos().y ) )
            {
                if( ( ( *( Element2d * * ) elem1 )->Pos().x ) >
                    ( ( *( Element2d * * ) elem2 )->Pos().x ) )
                    return 1;
                else
                    return -1;
            }else
                return -1;
        }

        //==========================================================================================
        //  Name : EntitySort
        //  Desc : sort role in map by distance and paste then in screen
        //==========================================================================================
        void Terrain2d::EntitySort( void )
        {
    		m_PasteEntity.clear();
			m_AlphaEntity.clear();

            if( IsEntityEmpty() )
                return;

            m_PasteEntity.allot( EntityCount() );  //�ƧǼȦs
			
            for( UINT i = 0;i < EntityCount();i++ )
			{
                m_PasteEntity[ i ] = _G2ROLE( Entity( i ) );
			}

            m_PasteEntity.qSort( compare2d );

			/*
            //===========Order sort==========================================================
            if( IsEntityEmpty() )
                return;

            Array<Role2d*> m_Temp_Object( EntityCount() );  //�ƧǼȦs

            for( UINT i = 0;i < EntityCount();i++ )
                m_Temp_Object[ i ] = _G2ROLE( Entity( i ) );

            m_Temp_Object.qSort( compare2d );

            //=================================================================================
            //�M���Ҧ����󪺩Ҧb��
            //m_MapObject.zero_value();
            for( UINT j = 0;j < m_Temp_Object.size();j++ )
            {
                if( m_Temp_Object[ j ]->Visible )
                    m_pRender->AlphaBlit( m_Temp_Object[ j ]->Animation(),
                                          m_Temp_Object[ j ]->ScreenPos(),
                                          canvas );
            }
            m_Temp_Object.clear();
			*/
        }

        //==========================================================================================
        //  Name : RoleAlphaSort
        //  Desc : sort role in map by distance and paste then in screen
        //==========================================================================================
		void Terrain2d::RoleAlphaSort( void )
		{

		}

        //==========================================================================================
        //  Name : ElemAlphaSort
        //  Desc : sort role in map by distance and paste then in screen
        //==========================================================================================
		void Terrain2d::ElemAlphaSort( void )
		{

		}
		
        //==========================================================================================
        //  Name :
        //  Desc :
        //==========================================================================================
		void Terrain2d::RenderEntity( CPIcon* canvas )
		{
			for( UINT j = 0;j < m_PasteEntity.size();j++ )
			{
                if( m_PasteEntity[ j ]->Visible )
                    m_pRender->AlphaBlit( m_PasteEntity[ j ]->Animation(),
                                          m_PasteEntity[ j ]->ScreenPos(),
                                          canvas );
            }

			for( j = 0;j < m_AlphaEntity.size();j++ )
			{
                if( m_AlphaEntity[ j ]->Visible )
                    m_pRender->Alpha16DarkenBlit( m_AlphaEntity[ j ]->Animation(),
                                                  m_AlphaEntity[ j ]->ScreenPos(),
                                                  canvas );

			}
		}

        //==========================================================================================
        //  Name :
        //  Desc :
        //==========================================================================================
		void Terrain2d::RenderTerrain( CPIcon* canvas )
		{
            if( m_pRender == NULL )
                return;
			for( UINT i=0; i<m_pLoadedCellVec.size(); i++ )
			{
                if( ( Visible ) && ( m_pRender->GetWidget() != NULL ) )
				{
					Zone2d* zone = (Zone2d*)GetCellData( m_pLoadedCellVec[i].x,
						                                 m_pLoadedCellVec[i].y );
					if( zone != NULL )
					{
                        m_pRender->AlphaBlit( zone->Animation(),
						                      zone->ScreenPos(),
							                  canvas );
					}
				}
			}
            return ;

		}

        //==========================================================================================
        //  Name :
        //  Desc :
        //==========================================================================================
        void Terrain2d::SetArea( char** array, int id )
        {
            for( UINT i = 0 ;i < GetRows() ;i++ )
                for( UINT j = 0 ;j < GetCols() ;j++ )
                    array[ i ][ j ] = id;
        }


        /*
        ////////////////////////////////////////////////////////////////////////////////////////////
        //
        ////////////////////////////////////////////////////////////////////////////////////////////
        CPRect Terrain2d::MapRect(void)
        {
            CPRect maprect( m_Situs.x, m_Situs.y, 
                            m_Situs.x + Scene_Width(), 
                            m_Situs.y + Scene_Height() );
            return maprect;
        }
        */

        //========================================================================================
        //  Name : Load_BG()
        //  Desc : load a elem file to be background 
        //========================================================================================
        int Terrain2d::LoadBackGround( const char* path )
        {
            //CPFile pf(path, "rb");
			m_pScreenDatum = &GetScreenDatum();
            return Element2d::Load( path );
        }

        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
        void Terrain2d::PasteBackGround( CPIcon* canvas )
        {
            if( m_pRender == NULL )
                return;
            if( ( Visible ) && ( m_pRender->GetWidget() != NULL ) )
                m_pRender->AlphaBlit( Animation(), ScreenPos(), canvas );
            return ;
        }


        //=============================================================================
        //  Name : 
        //  Desc :
        //=============================================================================
#define _MAP_RECT_LIMIT_ 100

        void Terrain2d::Collide_Scroll( POINT point )
        {
            if( m_pRender->GetWidget() == NULL )
                return;

            GVertex mouse_pt;
            GetCursorPos( &mouse_pt );
            ScreenToClient( ( HWND ) m_pRender->GetWidget(), &mouse_pt );

            LG::Rect client_rect;
            GetClientRect( ( HWND ) m_pRender->GetWidget(), &client_rect );

            if( PA::Intersect::Test( &client_rect, &mouse_pt ) )
            {
                if( point.x < _MAP_RECT_LIMIT_ )
                {
                    if( Element2d::Norm().x < 0 )
                    {
                        GVertex spt ( Element2d::Norm().x + 10,
                                      Element2d::Norm().y ); 
                        Pos() = spt;

                        point.x = _MAP_RECT_LIMIT_;
                    }
                }else if( point.x > m_pRender->GetWidth() - _MAP_RECT_LIMIT_ )
                {
                    if( Element2d::Norm().x >
                        ( m_pRender->GetWidth() - ImageWidth() ) )
                    {
                        GVertex spt ( Element2d::Norm().x - 10,
                                      Element2d::Norm().y );
                        Pos() = spt;

                        point.x = m_pRender->GetWidth() - _MAP_RECT_LIMIT_;
                    }
                }
                if( point.y < _MAP_RECT_LIMIT_ )
                {
                    if( Element2d::Norm().y < 0 )
                    {
                        GVertex spt ( Element2d::Norm().x,
                                      Element2d::Norm().y + 10 );
                        Pos() = spt;

                        point.y = _MAP_RECT_LIMIT_;
                    }
                }else if( point.y >
                          ( m_pRender->GetHeight() - _MAP_RECT_LIMIT_ ) )
                {
                    if( Element2d::Norm().y >
                        ( m_pRender->GetHeight() - ImageHeight() ) )
                    {
                        GVertex spt ( Element2d::Norm().x,
                                      Element2d::Norm().y - 10 );
                        Pos() = spt;

                        point.y = m_pRender->GetHeight() - _MAP_RECT_LIMIT_;
                    }
                }

                ClientToScreen( ( HWND ) m_pRender->GetWidget(), &point );
                SetCursorPos( point.x, point.y );
            }

            return;
        }


        //=============================================================================
        //
        //
        //=============================================================================
        //int m_ScrollSpeed;

        void Terrain2d::Query( GVertex point, UINT uMsg, UINT wParam )
        {
            switch( uMsg )
            {
            case WM_MOUSEMOVE://==deviec situs=================
            m_Mouse_Map_Site = ScreenToMapSite( point );
            //��l�y��
            m_Mouse_Chessboard_Site = MapToChessboardSite( m_Mouse_Map_Site );
            //===============================

            break;
            }

            Collide_Scroll( point );

            return ;
        }



        //=============================================================================
        //
        //
        //=============================================================================

	    //=============================================================================
        //  Name : LoadScript()
        //  Desc : Load script language file
        //=============================================================================
        class CPTerrainScript : public CPGSPFile
        {
        public :

			Terrain2d* pTerrain;

			struct SectorData
			{
				char filename[MAX_PATH];
				INT  x;
				INT  y;
			};

			/*
			struct TerrainData
			{
				INT  cx;
				INT  cy;
				INT  rh;
				INT  rw;
			};
			*/


            virtual void* OnCreateObject( const char* Name )
            {
                if( strcmp( Name, "2DTERRAIN" ) == 0 )
                {
					return pTerrain;
                }
                if( strcmp( Name, "2DSECTOR" ) == 0 )
                {
					SectorData* s = new SectorData;
					return s;
                }
                if( strcmp( Name, "2DROLE" ) == 0 )
				{
					GE::World::Role2d* role = new GE::World::Role2d;
					return role;
				}
                return NULL;
            }


            virtual void OnReadAttribute( const char* Name,
                                          void* obj,
                                          char* Attribute,
                                          char* Value )
            {
                if( strcmp( Name, "2DTERRAIN" ) == 0 )
                {
                    //TerrainData* t = ( TerrainData* ) obj;
                    if( strcmp( Attribute, "SEGMENT" ) == 0 )
                    {
						int cx = atof( strtok( Value, "," ) );
				        int cy = atof( strtok( NULL, "," ) );
				        int rw = atof( strtok( NULL, "," ) );
						int rh = atof( strtok( NULL, "," ) );
						pTerrain->Create( cx, cy, rw, rh );
                    }
					/*
                    if( strcmp( Attribute, "CX" ) == 0 )
                    {
						t->cx = atoi( Value );
                    }
					else if( strcmp( Attribute, "CY" ) == 0 )
                    {
						t->cy = atoi( Value );
                    }
                    else if( strcmp( Attribute, "REGIONW" ) == 0 )
                    {
						t->rw = atoi( Value );
                    }
					else if( strcmp( Attribute, "REGIONH" ) == 0 )
                    {
						t->rh = atoi( Value );
                    }
					*/
                }
				else if( strcmp( Name, "2DSECTOR" ) == 0 )
                {
					SectorData* s = ( SectorData* ) obj;
                    if( strcmp( Attribute, "X" ) == 0 )
                    {
						s->x = atoi( Value );
                    }
					else if( strcmp( Attribute, "Y" ) == 0 )
                    {
						s->y = atoi( Value );
                    }
					else if( strcmp( Attribute, "LOAD" ) == 0 )
					{
						_makepath(  s->filename, NULL, Terrain2d::GetWorkDirectory(), Value, NULL );
                    }
                }
				else if( strcmp( Name, "2DROLE" ) == 0 )
                {
					GE::World::Role2d* role =  (GE::World::Role2d*)obj;
                    if( strcmp( Attribute, "X" ) == 0 )
                    {
						role->Pos().x = atoi( Value );
                    }
					else if( strcmp( Attribute, "Y" ) == 0 )
                    {
						role->Pos().y = atoi( Value );
                    }
					else if( strcmp( Attribute, "LOAD" ) == 0 )
                    {
						char buf[_MAX_PATH];
						_makepath(  buf, NULL, Terrain2d::GetWorkDirectory(), Value, NULL );
						role->Load( buf );
                    }
					else if( strcmp( Attribute, "DATABASE" ) == 0 )
					{
						char* name  = strtok( Value, "," );
				        UINT  entry = atoi( strtok( NULL, "," ) );
						role->SetDataBaseName( name );
						role->SetDataBaseEntry( entry );
					}
                }

            }
            virtual void OnCloseObject( const char* Name, void* obj )
            {
				/*
                if( strcmp( Name, "2DTERRAIN" ) == 0 )
                {
                    TerrainData* t = ( TerrainData* ) obj;
					if( pTerrain != NULL )
					{
						int cx = atof( strtok( value, "," ) );
				        int cx = atof( strtok( NULL, "," ) );
				        int rw = atof( strtok( NULL, "," ) );
						int rh = atof( strtok( NULL, "," ) );
						pTerrain->Create( cx, cy, rw, h );
					}
					delete t;
				}
				*/
				if( strcmp( Name, "2DSECTOR" ) == 0 )
				{
					SectorData* s = ( SectorData* ) obj;
					pTerrain->InsertCell( s->filename, 
						                    s->x,
											s->y );
				}

				if( strcmp( Name, "2DROLE" ) == 0 )
				{
					GE::World::Role2d* role =  (GE::World::Role2d*)obj;
					pTerrain->JoinRole( role );
				}

                return;
            }
        };

        int Terrain2d::Load( const char* path )
        {
            //CPG2Scene::Load(path);

            //Scene_Width()   = Scene_Width();
            //Scene_Height()  = Scene_Height();
			CPTerrainScript reader;
			reader.pTerrain = this;
            return reader.Load( path );
        }

        //=============================================================================
        //
        //
        //=============================================================================
        void Terrain2d::Save( const char* path )
        {
            //CPG2Scene::Save( path, (Element2d*)this, getUnits() );
			CPTerrainScript writer;

			char buf[ 255 ];

            writer.Open( path );

            writer.CreateObject( "2DTERRAIN" );
			sprintf( buf, "%d,%d,%s,%s", GetCols(), GetRows(),
				                         GetCellWidth(),
										 GetCellHeight() );

			writer.SetReadAttribute( "SEGMENT", buf );
 
			for( UINT r=0; r<GetRows(); r++ )
			{
				for( UINT c=0; c<GetCols(); c++ )
				{
					writer.CreateObject( "2DSECTOR" );
					writer.SetReadAttribute( "X", itoa( c, buf, 10 ) );
					writer.SetReadAttribute( "Y", itoa( r, buf, 10 ) );

					char* name = (char*)GetCellName( c, r );

					if( GetWorkDirectory()!= NULL )
					{
						char* s;
						s=strstr( name, GetWorkDirectory() );
						if( s!=NULL )
						{
							name = s;
							name+= ( strlen( GetWorkDirectory() ) + 1 );
						}
					}
					writer.SetReadAttribute( "LOAD", name );
					writer.CloseObject();
				}
			}

			for( UINT e=0; e<EntityCount(); e++ )
			{
				GE::World::Role2d* role = Role( e );

				writer.CreateObject( "2DROLE" );
				writer.SetReadAttribute( "X", itoa( role->Pos().x, buf, 10 ) );
				writer.SetReadAttribute( "Y", itoa( role->Pos().y, buf, 10 ) );

				char* name = (char*)role->GetFileName();
				if( GetWorkDirectory()!= NULL )
				{
					char* s;
					s=strstr( name, GetWorkDirectory() );
					if( s!=NULL )
					{
						name = s;
						name+= ( strlen( GetWorkDirectory() ) + 1 );
					}
				}
    			writer.SetReadAttribute( "LOAD", name );

				sprintf( buf, "%s,%d", role->GetDataBaseName(), role->GetDataBaseEntry() );
				writer.SetReadAttribute( "DATABASE", buf );
				writer.CloseObject();
			}

			writer.CloseObject();
        }

        //=============================================================================
        //
        //
        //=============================================================================
        void Terrain2d::OnGetNeighbor( UINT gx, UINT gy,
  			                           std::vector< LG::Point >& neighbor )
		{
			neighbor.resize( 9 );
			neighbor[0].x = gx-1; neighbor[0].y = gy-1;
			neighbor[1].x = gx;   neighbor[1].y = gy-1;
			neighbor[2].x = gx+1; neighbor[2].y = gy-1;
			neighbor[3].x = gx-1; neighbor[3].y = gy;
			neighbor[4].x = gx;   neighbor[4].y = gy;
			neighbor[5].x = gx+1; neighbor[5].y = gy;
			neighbor[6].x = gx-1; neighbor[6].y = gy+1;
			neighbor[7].x = gx;   neighbor[7].y = gy+1;
			neighbor[8].x = gx+1; neighbor[8].y = gy+1;
		}

        //=============================================================================
        //
        //
        //=============================================================================
		void* Terrain2d::OnLoadCell( const char* filename,
			                               void** pData,
			                               void** pUserdata )
		{
			if( (*pData) != NULL )
				return NULL;
			Zone2d* zone=NULL;
			zone = new Zone2d;
			zone->m_pScreenDatum = &GetScreenDatum();
			( (GE::Element2d*)zone )->Load( filename );
			(*pData) = zone;
			return zone;
		}

        //=============================================================================
        //
        //
        //=============================================================================
		void Terrain2d::OnReleaseCell( const char* filename,
			                           void* pData,
					                   void* pUserdata )
		{
			Zone2d* zone = (Zone2d*)pData;
			delete zone;
			return;
		}

    };//World
};//GE


